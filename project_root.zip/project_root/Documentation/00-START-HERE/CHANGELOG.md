# 📜 CHANGELOG
تاریخچه تغییرات پروژه

همه تغییرات قابل توجه این پروژه در این فایل مستند می‌شوند.

فرمت بر اساس [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)  
این پروژه از [Semantic Versioning](https://semver.org/spec/v2.0.0.html) پیروی می‌کند.

---

## [Unreleased]

### در حال توسعه
- Sprint 1 implementation در حال انجام
- Core interfaces در حال تعریف

---

## [2.2.0] - 2026-02-16

### 🚀 Phase 1 Strategic Documents (MVP Execution Lock)

این نسخه شامل **5 سند استراتژیک فاز 1** است که قبل از شروع Build الزامی‌اند.

### ✨ Added (اضافه شده)

#### Phase 1 Mandatory Documents:

- **Architecture_Commitment_Matrix_FINAL.txt**
  - تفکیک MVP-Core (9 ماژول) + MVP-Hardening
  - زمان واقع‌بینانه: 45-65 روز کاری
  - Definition of Done مهندسی‌محور
  - KPI های عددی دقیق
  
- **KPI_Lock_FINAL.txt**
  - 4 Critical KPIs + 4 Important KPIs
  - Environment Lock (Local-only, Hardware baseline)
  - Test Dataset Lock (20 ورودی رسمی)
  - Token Policy: Shot <= 250, Scene <= 1200
  - Quality Scoring Rubric (0-100)
  - Coverage: Critical Path >= 80%, Overall >= 60%
  
- **Stack_Lock_FINAL.txt**
  - Python 3.11+ با 10 dependencies فقط
  - Pipeline Orchestrator اجباری (core/pipeline.py)
  - JSON-only persistence در MVP (SQLite → Phase 2)
  - Standard logging (structlog → Phase 2)
  - Pydantic Strict Mode
  - Anti-Drift Rules سخت‌گیرانه
  
- **Failure_Philosophy_FINAL.txt**
  - 7 سناریو failure + استراتژی
  - Architectural Flow: Layer → Pipeline → CLI
  - Structured Error Contract
  - Exit Codes استاندارد (0, 1, 2, 3)
  - ممنوعیت print/sys.exit در core layers
  - Token Overflow: <= 250 OK, 250-350 Warning, > 350 Error
  - Logging متصل به KPI metrics
  
- **Vertical_Slice_Design_FINAL.txt**
  - Pipeline 11 مرحله‌ای کاملاً مشخص
  - Token Policy دقیق (aligned با KPI)
  - Format-Agnostic Output (No Midjourney coupling)
  - Scene Source Rule (No hardcoded narrative)
  - Performance Targets: < 10s total, < 500 MB memory
  - Test Requirements updated
  - Architectural Guarantees

- **MVP_Structure_Complete.txt**
  - ساختار کامل directory پروژه (75 فایل)
  - شامل همه 10 مورد پیشنهادی
  - نمونه کدهای کامل: pyproject.toml, config.yaml, exceptions.py, constants.py, types.py
  - همه __init__.py ها با exports واضح
  - tests/conftest.py با fixtures
  - scripts/ برای validation و KPI measurement
  - .gitignore و runtime directories
  - راهنمای setup و development workflow

### 🔧 Changed (تغییر یافته)

- **همسویی کامل بین اسناد:**
  - همه 5 سند کاملاً aligned با یکدیگر
  - Token Policy یکسان در همه جا
  - No contradictions
  - Single source of truth

### 📊 Statistics

- تعداد فایل‌های مستندات: 79 → 85 (+6)
- اسناد استراتژیک فاز 1: 0 → 6
- حجم کل مستندات: ~1.2 MB → ~1.5 MB

### 🎯 Impact

این 5 سند = **قفل اجرایی قبل از Build**:
- تصمیمات معماری قطعی
- KPI های قابل اندازه‌گیری
- Stack تکنولوژی ثابت
- Error handling واضح
- Vertical Slice آماده

**بدون این اسناد = خطر Architecture Drift**
**با این اسناد = Build منظم و قابل پیش‌بینی**

---

## [2.1.0] - 2026-02-10

### 📚 Documentation & Tools Expansion

این نسخه شامل گسترش قابل توجه مستندات و ابزارهای کمکی است.

### ✨ Added (اضافه شده)

#### New Documentation Files:
- **13-Naming_Conventions_FA.txt**
  - قواعد جامع نام‌گذاری فایل‌ها، متغیرها، فانکشن‌ها
  - چک‌لیست سریع و anti-patterns
  - 20 بخش کامل با مثال‌های عملی

- **14-Glossary_FA.txt**
  - تعریف 50+ اصطلاح تخصصی پروژه
  - دسته‌بندی شده (معماری، سینما، Prompt Engineering، داده)
  - یکسان‌سازی زبان و اصطلاحات

- **TROUBLESHOOTING_FA.txt**
  - راهنمای رفع مشکلات رایج (15 مشکل + راه‌حل)
  - مشکلات شروع کار، AI، ساختار، پیاده‌سازی
  - چک‌لیست عیب‌یابی سریع
  - راه‌حل‌های عملی با مثال

#### Updated Files:
- **60-Cross_Reference_Map_FA.txt (v2.0)**
  - گسترش از 4 فایل به 75 فایل
  - ماتریس کامل وابستگی‌های Blueprint
  - Data Flow Map جامع
  - راهنمای استفاده و قوانین Cross-Reference

#### New Tools:
- **validate_project.py**
  - اسکریپت Python برای Validation خودکار
  - بررسی 29 Blueprint و ساختار پروژه
  - چک کردن naming conventions و dependencies
  - خروجی JSON برای CI/CD
  - همراه با README کامل

### 🔄 Changed (تغییر یافته)

- **1-Master_Blueprint_Index_FA.txt**
  - اضافه شدن فایل‌های جدید
  - بروزرسانی تاریخ به 2026-02-10

### 📊 Statistics

- تعداد فایل‌های مستندات: 75 → 79 (+4)
- حجم کل مستندات: ~1.0 MB → ~1.2 MB
- ابزارهای Automation: 0 → 1
- نمونه کدها: 0 → 4

---

## [2.0.0] - 2026-02-06

### 🎉 Major Release: Blueprint v2.0

این نسخه یک بازنگری کامل و گسترش قابل توجه از Blueprint Master است.

### ✨ Added (اضافه شده)

#### New Modules (ماژول‌های جدید):
- **Style Matrix Manager** (Module 19)
  - پشتیبانی از چندین سبک بصری همزمان
  - امکان ترکیب سبک‌ها (مثلاً 70% Ghibli + 30% Realistic)
  - تعریف سبک‌های سفارشی

- **Cinematic Language Controller** (Module 20)
  - کنترل ضرب‌آهنگ سینمایی (Long-take / Fast-cut / Hybrid)
  - تنظیمات زبان بصری

- **Beat Sheet Manager** (Module 21)
  - مدیریت زمان‌بندی دقیق هر ثانیه
  - Timeline second-by-second
  - Timing control برای Animation

- **Motion Intensity Controller** (Module 22)
  - کنترل دقیق سرعت و شدت حرکت
  - Subject motion speed
  - Camera motion speed
  - Motion blur control

- **Audio Context Generator** (Module 23)
  - تولید خودکار توصیفات صوتی
  - بر اساس محیط و اتفاقات
  - Sound design hints

- **Reference Image Manager** (Module 24)
  - مدیریت تصاویر مرجع (Cref/Sref)
  - حفظ Continuity
  - Image reference tokens برای Midjourney/Sora

- **Logic Conflict Checker** (Module 25)
  - جلوگیری از اشتباهات کارگردانی
  - تشخیص تناقض‌های فنی
  - Warning system

- **Prompt Cleaner** (Module 26)
  - تمیزکاری و بهینه‌سازی پرامپت
  - حذف تناقضات و تکرارها
  - Token optimization

- **Token Cost Calculator** (Module 27)
  - تخمین هزینه قبل از ارسال
  - محاسبه برای هر مدل AI
  - Cost report

#### Enhanced Modules (ماژول‌های بهبود یافته):
- **Project DNA Manager**
  - اضافه شدن Master Palette
  - Cinematic Language settings
  - Global Mood base

- **Shot Engine**
  - پشتیبانی از Beat Sheet
  - Multi-Outfit/Expression/Props system

- **Camera System**
  - Lens Physics detail (14mm - 200mm)
  - Camera Motion Types (Orbit, Crane, Dolly Zoom, etc.)
  - Depth of Field control

- **Environment Engine**
  - Atmospheric Mixing
  - Environment Props Library
  - Anti-hallucination measures

- **Asset Library**
  - Multi-Outfit system
  - Multi-Expression system
  - Multi-Props system

- **Validation Engine**
  - Beat Sheet timing validation
  - Reference image format validation
  - Enhanced checking

#### Master Documents:
- **Product Strategy Master** (80+ pages)
  - ادغام 6 فایل Product Strategy
  - Comprehensive strategy document

- **AI Governance Master**
  - ادغام AI Development Contract
  - AI Guardrails Final
  - Version Roadmap

- **Pre-Build Philosophy & Readiness Master**
  - ادغام 7 فایل Philosophy
  - Complete readiness checklist
  - GO/NO-GO decision framework

- **Execution Backlog Master**
  - 18 Epics across 4 phases
  - 13-18 weeks timeline
  - Detailed task breakdown

- **Feature Gating Master**
  - 30+ features
  - 4 role-based access levels
  - Complete implementation guide

- **Sprint 1 Task List Detailed**
  - 5 Task Groups
  - Day-by-day timeline
  - Complete code examples

- **AI Coding Prompt Template Complete**
  - 80+ pages
  - 30+ DO/DON'T examples
  - Complete guidelines

### 🔄 Changed (تغییر یافته)

#### Architecture:
- Data Flow اضافه شدن Beat Sheet بین Scene و Shot
- Audio Context Generator اضافه شده به Pipeline
- Logic Conflict Checker اضافه شده به Validation
- Prompt Cleaner و Token Cost Calculator اضافه شده قبل از Output

#### Module Interaction Matrix:
- گسترش یافته برای ماژول‌های جدید
- Dependency map بروزرسانی شده

### 📚 Documentation:
- Master Blueprint Index به v2.0 ارتقا یافت
- 29 ماژول فرعی Blueprint (بعضی جدید، بعضی بروز شده)
- ساختار Documentation بازنگری شد
- 6 Master Document جدید

### 🎯 Performance Considerations:
- Image Reference Pre-loading برای سرعت
- Progressive rendering در UI
- Caching strategies

### 🔒 Security:
- Uploaded Image Validation (size, format, malware scan)
- Enhanced data integrity rules

---

### 🐛 Fixed (رفع شده)
- تناقضات در Blueprint Master v1
- Gap های Documentation
- Inconsistency در Module descriptions

---

### 🗑️ Removed (حذف شده)
- فایل‌های Deprecated از v1
- Documentation قدیمی و Outdated

---

### 📊 Statistics (آمار v2.0):
```
Modules: 27 → 29 (+2)
Master Documents: 1 → 7 (+6)
Documentation Pages: ~200 → ~500 (+150%)
Features Defined: ~15 → 30+ (+100%)
Implementation Details: Basic → Complete
Code Examples: Few → Many
```

---

## [1.0.0] - 2026-01-15

### 🎉 Initial Release: Blueprint Master v1.0

اولین نسخه رسمی Blueprint Master

### ✨ Added

#### Core Modules (27 ماژول):
1. Story Wizard
2. Human Override Interface
3. Project DNA Manager
4. Scene Engine
5. Shot Engine
6. Asset Library
7. Character & Subject System
8. Validation Engine
9. Dependency Resolver
10. Camera System
11. Lighting System
12. Environment & Weather Engine
13. Prompt Engineering Core
14. State & Versioning System
15. Output Target Profiles
16. Output Composer
17. Bilingual System
18. Save/Load Manager
19. Backup System
20. Export/Import Manager
21. Project Data Schema
22. User Workflow
23. Architect Notes
24. NonGoals
25. Enforcement Rules
26. Risk Register
27. PreCoding Checklist

#### Architecture:
- Layered Architecture (6 layers)
- Zone-based separation (Core/Product/Private)
- Modular design

#### Documentation:
- Blueprint Master v1.0
- Basic module descriptions
- Data flow diagram
- Module interaction matrix

### 🎯 Philosophy:
- Human-controlled AI
- Core immutability
- Clear boundaries
- Documentation-first

---

## [0.5.0] - 2026-01-01

### 🔧 Pre-release: Proof of Concept

### ✨ Added
- Initial architecture concept
- Basic folder structure
- Core principles document
- Preliminary module list

### 📝 Notes
- Experimental phase
- Architecture testing
- Concept validation

---

## 🏷️ Version Format

```
[MAJOR.MINOR.PATCH]

MAJOR: تغییرات ناسازگار (Breaking changes)
MINOR: افزودن قابلیت (Backwards compatible)
PATCH: رفع باگ (Backwards compatible)

مثال:
- 1.0.0 → 2.0.0: Breaking changes (معماری تغییر کرد)
- 2.0.0 → 2.1.0: New features (ماژول جدید اضافه شد)
- 2.1.0 → 2.1.1: Bug fixes (باگ fix شد)
```

---

## 📋 Types of Changes

این پروژه از این دسته‌بندی استفاده می‌کند:

- **✨ Added**: قابلیت‌های جدید
- **🔄 Changed**: تغییر در قابلیت‌های موجود
- **🗑️ Deprecated**: قابلیت‌هایی که قرار است حذف شوند
- **🗑️ Removed**: قابلیت‌های حذف شده
- **🐛 Fixed**: رفع باگ
- **🔒 Security**: رفع مشکلات امنیتی

---

## 🔮 Roadmap (برنامه آینده)

### v2.1.0 (Planned - Q1 2026)
- [ ] Sprint 1 complete implementation
- [ ] Core interfaces production-ready
- [ ] Basic Product Facade operational
- [ ] First end-to-end generate flow working

### v2.2.0 (Planned - Q2 2026)
- [ ] Power User features
- [ ] Advanced validation
- [ ] History & versioning
- [ ] Enhanced UI

### v3.0.0 (Planned - Q3-Q4 2026)
- [ ] Production release
- [ ] Full feature set
- [ ] API stable
- [ ] Performance optimized

---

## 📝 How to Contribute to CHANGELOG

هنگام ایجاد PR، لطفاً:

1. تغییرات خود را در بخش `[Unreleased]` اضافه کنید
2. از دسته‌بندی مناسب استفاده کنید (Added/Changed/Fixed/etc.)
3. توضیح واضح و مختصر بنویسید
4. در صورت لزوم، Issue number را ذکر کنید

### مثال:

```markdown
## [Unreleased]

### Added
- New validation for shot duration (#123)
- Support for custom aspect ratios (#125)

### Fixed
- Bug in camera angle calculation (#124)
```

---

## 🔗 لینک‌های مفید

- [Repository](https://github.com/your-repo)
- [Issues](https://github.com/your-repo/issues)
- [Pull Requests](https://github.com/your-repo/pulls)
- [Documentation](./Documentation/)

---

## 📞 سوالات؟

اگر سوالی درباره تغییرات دارید:
- Issue باز کنید با tag `question`
- مستندات را مطالعه کنید
- با Owner تماس بگیرید

---

📅 Last Updated: 2026-02-08  
📝 Maintained by: Project Owner  
✅ Status: Active

---

## 🎓 نکات برای خواندن CHANGELOG

```
این فایل برای:
✓ دیدن تاریخچه پروژه
✓ فهمیدن چی تغییر کرده
✓ دنبال کردن پیشرفت
✓ تصمیم‌گیری درباره Upgrade

نحوه خواندن:
1. از بالا (Unreleased) شروع کن
2. به سمت پایین (قدیمی‌تر) برو
3. به نسخه‌هایی که برات مهمه دقت کن
4. Breaking changes رو جدی بگیر
```

---

**Keep this file updated!** 📝
