# 🚀 QUICK START GUIDE
راهنمای شروع سریع - فقط 5 دقیقه!

---

## 👋 خوش اومدی!

این راهنما برای شروع **سریع** است. اگه می‌خوای جزئیات بیشتر، بعداً اسناد کامل رو بخون.

**زمان مورد نیاز:** 5 دقیقه  
**هدف:** بفهمی پروژه چیه و از کجا شروع کنی

---

## 📍 مرحله 1: بفهم پروژه چیه (1 دقیقه)

### این پروژه چیه?

```
یک Cinema Shot Generation Platform

که:
✓ پرامپت حرفه‌ای برای AI مدل‌ها می‌سازه
✓ معماری Layered داره (6 لایه)
✓ AI رو کنترل می‌کنه (نه اینکه AI کنترل کنه!)
✓ مستندسازی جامع داره
```

### اصول کلیدی:

```
1. Human تصمیم می‌گیره، AI اجرا می‌کنه
2. Core غیرقابل تغییر است
3. معماری > فیچر
4. کنترل > سرعت
```

**الان چی باید بکنی؟**  
→ ادامه بده به مرحله 2

---

## 🎯 مرحله 2: تو کی هستی؟ (30 ثانیه)

انتخاب کن:

### 🔧 من Developer هستم
→ **برو به بخش A** (پایین)

### 🏗️ من Architect/Owner هستم  
→ **برو به بخش B** (پایین)

### 👔 من Stakeholder/Manager هستم
→ **برو به بخش C** (پایین)

### 🤖 من AI Assistant هستم
→ **برو به بخش D** (پایین)

---

## A) برای Developer (توسعه‌دهنده)

### چیکار کنم?

```
مسیر پیشنهادی:

1. بخون (ترتیب مهمه):
   □ این فایل (همین که الان می‌خونی) ✓
   □ Master_Blueprint_Index_FA.txt (نقشه کلی)
   □ Pre_Build_Philosophy_Readiness_Master_FA.txt
   □ Sprint_1_Task_List_Detailed_FA.txt

2. Setup کن:
   □ Git clone/pull
   □ بخون CONTRIBUTING.md
   □ Setup environment (Python + Node)

3. شروع کن:
   □ برو به Sprint 1
   □ شروع کن از Task Group 1
   □ مطابق Sprint Task List پیش برو
```

### فایل‌های مهم برات:

```
باید بخونی:
- /04-Implementation/Sprint_1_Task_List_Detailed_FA.txt
- /05-AI-Development/AI_Coding_Prompt_Template_Complete_FA.txt
- /07-Master-Blueprints/01-Blueprint_Master_FA_v2.0.txt

خوبه بخونی:
- /01-Core-Philosophy/ (همه)
- /03-AI-Governance/AI_Governance_and_Product_Evolution_Master_FA.txt
```

### چیزهایی که نباید بکنی:

```
❌ Core رو تغییر ندی (Read-Only است!)
❌ بدون مستند کردن تصمیم نگیری
❌ AI Guardrails رو نادیده نگیری
❌ Zone Boundaries رو نشکنی
```

**آماده‌ای؟** برو Sprint 1!

---

## B) برای Architect/Owner (معمار/مالک)

### چیکار کنم?

```
مسیر پیشنهادی:

1. بخون Philosophy (30 دقیقه):
   □ Pre_Build_Philosophy_Readiness_Master_FA.txt
   □ /01-Core-Philosophy/ (همه فایل‌ها)
   □ Architecture_Philosophy_FA.txt

2. بررسی کن Architecture (30 دقیقه):
   □ Blueprint_Master_FA_v2.0.txt
   □ Module_Boundaries_FA.txt
   □ همه Blueprint های Layer 1-6

3. بررسی کن Governance (20 دقیقه):
   □ AI_Governance_and_Product_Evolution_Master_FA.txt
   □ Human_In_The_Loop_and_Override_Policy_FA.txt

4. برنامه‌ریزی کن (20 دقیقه):
   □ Execution_Backlog_Master_FA.txt
   □ Feature_Gating_Master_FA.txt
   □ Product_Strategy_Master_FA.txt
```

### Checklist قبل از شروع:

```
آیا:
□ Philosophy رو خوندم و قبول دارم؟
□ Architecture رو فهمیدم؟
□ Governance rules رو می‌پذیرم؟
□ آماده Build Mode هستم؟ (بدون عجله)

اگه همه ✓ → شروع کن
اگه یکی ✗ → برگرد و بخون دوباره
```

**آماده‌ای؟** Check کن Final Checklist در Pre_Build_Philosophy!

---

## C) برای Stakeholder/Manager (ذینفع/مدیر)

### چیکار کنم?

```
مسیر پیشنهادی (سریع):

1. بخون خلاصه (10 دقیقه):
   □ این فایل
   □ Product_Strategy_Master_FA.txt (بخش 1-3)

2. ببین Roadmap (5 دقیقه):
   □ Product_Strategy_Master_FA.txt (Part 6: Roadmap)
   □ Execution_Backlog_Master_FA.txt (خلاصه)

3. بفهم Philosophy (5 دقیقه):
   □ Pre_Build_Philosophy_Readiness_Master_FA.txt (Part 1-2)

خلاصه:
- پروژه 3 Version داره (v1, v2, v3)
- v1 = MVP (3-4 ماه)
- معماری محکم و قابل گسترش
- AI کنترل شده، نه خودمختار
```

### سوالات متداول:

```
Q: کی آماده میشه؟
A: v1 MVP در 3-4 ماه، ولی فوکوس روی کیفیت است نه سرعت

Q: چه کسی کنترل داره؟
A: انسان (Owner) همیشه کنترل داره، AI فقط اجرا می‌کنه

Q: قابل گسترش است؟
A: بله، معماری Modular و Layered برای Scale طراحی شده

Q: چقدر ریسک داره?
A: کم - چون Governance محکم و مستندسازی کامل است
```

**آماده‌ای؟** بررسی کن Product Strategy!

---

## D) برای AI Assistant (دستیار هوش مصنوعی)

### چیکار کنم?

```
⚠️ IMPORTANT: تو یک EXECUTOR هستی، نه DECISION MAKER

مسیر الزامی:

1. بخون قوانین (الزامی):
   □ AI_Coding_Prompt_Template_Complete_FA.txt
   □ AI_Governance_and_Product_Evolution_Master_FA.txt
   □ AI_DEVELOPMENT_CONTRACT (داخل Governance)
   □ AI_GUARDRAILS (داخل Governance)

2. Acknowledge کن:
   "من قوانین را خواندم و می‌پذیرم:
    - من Executor هستم نه Decision Maker
    - Human تصمیم می‌گیرد، من اجرا می‌کنم
    - در شک → STOP & ASK
    - Core READ-ONLY است
    - Zone Boundaries مقدس است"

3. شروع کن:
   فقط بعد از Acknowledge
```

### 10 Guardrails (خلاصه):

```
1. Core READ-ONLY
2. No autonomous decisions
3. در شک → ASK
4. هیچ Override بدون اجازه
5. Document همه چی
6. Zone boundaries
7. Error > Guess
8. Human-in-loop همیشه
9. Rollback همیشه ممکن
10. Never pretend to be human

همه رو بخون در AI_Governance!
```

**آماده‌ای؟** Acknowledge کن و شروع کن!

---

## 📚 مرحله 3: منابع اصلی (1 دقیقه)

### فایل‌های کلیدی که باید بدونی کجان:

```
📂 00-START-HERE/
   ├─ 1-Master_Blueprint_Index_FA.txt        ← نقشه کل پروژه
   ├─ 2-Pre_Build_Philosophy_Readiness_...  ← فلسفه و آمادگی
   └─ این فایل که داری می‌خونی!

📂 01-Core-Philosophy/
   └─ اصول بنیادین پروژه

📂 02-Product-Strategy/
   └─ Product_Strategy_Master_FA.txt         ← استراتژی محصول

📂 03-AI-Governance/
   └─ AI_Governance_and_Product_Evolution... ← حکمرانی AI

📂 04-Implementation/
   ├─ Execution_Backlog_Master_FA.txt        ← برنامه اجرا
   ├─ Feature_Gating_Master_FA.txt           ← کنترل دسترسی
   └─ Sprint_1_Task_List_Detailed_FA.txt     ← وظایف Sprint 1

📂 05-AI-Development/
   └─ AI_Coding_Prompt_Template_Complete...  ← راهنمای AI

📂 07-Master-Blueprints/
   └─ 01-Blueprint_Master_FA_v2.0.txt        ← Blueprint اصلی

📂 08-14/ (Layers 1-6 + Specialized)
   └─ 29 Blueprint Module
```

---

## 🎯 مرحله 4: شروع کن! (30 ثانیه)

### حالا چیکار کنم?

```
بر اساس اینکه کی هستی:

Developer:
→ برو به: Sprint_1_Task_List_Detailed_FA.txt
→ شروع کن از Task Group 1

Architect:
→ برو به: Pre_Build_Philosophy_Readiness_Master_FA.txt
→ Check کن Final Checklist

Stakeholder:
→ برو به: Product_Strategy_Master_FA.txt
→ بخون Part 6 (Roadmap)

AI Assistant:
→ برو به: AI_Coding_Prompt_Template_Complete_FA.txt
→ Acknowledge قوانین
```

---

## ❓ سوالات متداول

### Q1: از کجا شروع کنم؟
**A:** از همین فایل شروع کردی! حالا برو به فایلی که بالا گفته شد بر اساس نقشت.

### Q2: همه رو باید بخونم؟
**A:** نه! فقط فایل‌های مربوط به نقشت. Master Index نشون میده چی مهمه.

### Q3: چقدر طول می‌کشه یاد بگیرم؟
**A:** 
- Quick overview: 30 دقیقه
- خوب یاد بگیری: 2-3 ساعت  
- کامل Master بشی: 1 هفته

### Q4: اگه گیر کردم چیکار کنم?
**A:** 
1. بخون Troubleshooting Guide (اگه هست)
2. بخون مجدد Master Blueprint Index
3. بپرس از Owner/Architect
4. Check کن Anti-Patterns (چیزهای ممنوع)

### Q5: می‌تونم چیزی عوض کنم?
**A:** بستگی داره چی رو:
- Core → ❌ نه (فقط Owner)
- Product → ✓ بله (با قوانین)
- Docs → ✓ بله (با PR)
- بخون CONTRIBUTING.md برای جزئیات

---

## 🎓 نکات نهایی

### ✅ Do (انجام بده):
- Documentation رو جدی بگیر
- قوانین رو رعایت کن
- قبل از کدنویسی بخون
- در شک بپرس
- همه چیز رو مستند کن

### ❌ Don't (انجام نده):
- Core رو بدون اجازه تغییر ندی
- بدون خوندن Docs شروع نکن
- قوانین رو نادیده نگیر
- تصمیم بدون مستند نگیر
- عجله نکن

---

## 📞 کمک بیشتر

### اگه نیاز به راهنمایی بیشتر داری:

```
1. بخون: Master_Blueprint_Index_v2.txt
   (نقشه کامل پروژه)

2. بخون: فایل مربوط به نقشت
   (Developer → Sprint 1)
   (Architect → Philosophy)
   (etc.)

3. بخون: CONTRIBUTING.md
   (چطور مشارکت کنی)

4. پرسیدن:
   - از Owner/Architect
   - در Issues
   - در Discussions
```

---

## ✨ موفق باشی!

```
یادت باشه:

"این پروژه یک سفر است، نه یک مقصد.
 لذت ببر از ساختن،
 ولی هویتت رو گم نکن."

حالا برو و بساز! 🚀
```

---

📅 Last Updated: 2026-02-08  
📝 Version: 1.0  
✅ Status: Ready for Use

---

**Next Step:** بر اساس نقشت، برو به فایل بعدی! 👆
