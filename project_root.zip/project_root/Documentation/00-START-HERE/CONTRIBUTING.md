# 🤝 CONTRIBUTING GUIDE
راهنمای مشارکت در پروژه

---

## 📋 فهرست مطالب

1. [مقدمه](#مقدمه)
2. [قوانین کلی](#قوانین-کلی)
3. [چطور مشارکت کنم؟](#چطور-مشارکت-کنم)
4. [استانداردهای کد](#استانداردهای-کد)
5. [استانداردهای Documentation](#استانداردهای-documentation)
6. [فرآیند Review](#فرآیند-review)
7. [نکات مهم](#نکات-مهم)

---

## 🎯 مقدمه

### خوش اومدی!

ممنون که می‌خوای به این پروژه کمک کنی! 🎉

این راهنما بهت می‌گه:
- چطور می‌تونی کمک کنی
- چه قوانینی رعایت کنی
- چطور تغییراتت رو بفرستی

**مهم:** این پروژه قوانین خاصی داره. لطفاً جدی بگیر.

---

## ⚖️ قوانین کلی

### قانون طلایی:

```
این پروژه یک فلسفه و هویت مشخص دارد.
هیچ تغییری نباید این هویت را از بین ببرد.
```

### قوانین مطلق (غیرقابل مذاکره):

#### 1️⃣ Core غیرقابل تغییر است

```
❌ FORBIDDEN:
- تغییر در /core/ بدون تأیید Owner
- Bypass کردن Zone Boundaries
- تغییر معماری بدون توافق

✅ ALLOWED:
- Bug fix در Core (با تأیید Owner)
- بهبود Performance (با تأیید)
- اضافه کردن Tests
```

---

#### 2️⃣ AI Guardrails رعایت شوند

```
اگه داری با AI کار می‌کنی:

✅ باید:
- AI_Coding_Prompt_Template رو بخونی
- 10 Guardrails رو رعایت کنی
- در شک بپرسی

❌ نباید:
- AI رو Autonomous بذاری
- Zone Boundaries رو بشکنی
- بدون تأیید تصمیم بگیری
```

---

#### 3️⃣ همه چیز مستند شود

```
هر تغییر باید:
- دلیلش واضح باشه
- مستند بشه
- در CHANGELOG ثبت بشه

بدون Documentation = تغییر رد می‌شه
```

---

#### 4️⃣ Test قبل از Push

```
قبل از Push:
□ همه Tests passing باشن
□ Code formatted باشه (black/prettier)
□ No warnings
□ Documentation updated

اگه یکی ✗ → Fix کن قبل از Push
```

---

## 🚀 چطور مشارکت کنم?

### گام به گام:

#### مرحله 1: Setup

```bash
# 1. Fork the repository
# در GitHub روی Fork کلیک کن

# 2. Clone کن
git clone https://github.com/YOUR_USERNAME/cinema-shot-platform.git
cd cinema-shot-platform

# 3. Add upstream
git remote add upstream https://github.com/ORIGINAL_OWNER/cinema-shot-platform.git

# 4. Virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# یا .venv\Scripts\activate  # Windows

# 5. Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

---

#### مرحله 2: Create Branch

```bash
# 1. Update main
git checkout main
git pull upstream main

# 2. Create feature branch
git checkout -b feature/your-feature-name

# یا برای fix:
git checkout -b fix/bug-description

# Naming convention:
# - feature/add-validation-engine
# - fix/core-boundary-leak
# - docs/update-blueprint-master
# - refactor/cleanup-shot-engine
```

---

#### مرحله 3: Make Changes

```bash
# 1. کارت رو انجام بده
# 2. Test کن مرتب
pytest tests/

# 3. Format کن
black .
prettier --write "**/*.{js,jsx,md,json}"

# 4. Commit کن (معنادار)
git add .
git commit -m "feat: add validation for shot duration

- Add max duration check (60s)
- Add min duration check (1s)
- Update tests
- Update documentation

Refs #123"
```

**Commit Message Format:**

```
<type>: <subject>

<body>

<footer>

Types:
- feat: فیچر جدید
- fix: رفع باگ
- docs: تغییر Documentation
- refactor: Refactor کد
- test: اضافه کردن Test
- chore: کارهای جانبی
```

---

#### مرحله 4: Push & PR

```bash
# 1. Push branch
git push origin feature/your-feature-name

# 2. Create Pull Request در GitHub
# - عنوان واضح
# - توضیح کامل
# - لینک به Issue (اگه هست)
# - Screenshot (اگه UI هست)

# 3. منتظر Review بمون
```

---

## 📝 استانداردهای کد

### Python Code:

```python
# ✅ GOOD

def validate_shot_duration(duration: int) -> bool:
    """
    Validate shot duration
    
    Args:
        duration: Duration in seconds
        
    Returns:
        True if valid, False otherwise
        
    Raises:
        ValueError: If duration is negative
    """
    if duration < 0:
        raise ValueError("Duration cannot be negative")
    
    return 1 <= duration <= 60


# ❌ BAD

def validate(d):
    # no type hints
    # no docstring
    # no error handling
    return d > 0 and d < 60
```

### قوانین Python:

```
✅ DO:
- Type hints همه جا
- Docstrings برای public functions
- Descriptive variable names
- PEP 8 compliance
- Error handling proper

❌ DON'T:
- Global variables
- Magic numbers
- Single-letter variables (جز i, j, k در loops)
- Wildcard imports (from x import *)
```

---

### JavaScript/React Code:

```javascript
// ✅ GOOD

/**
 * Generate button component
 * @param {Object} props - Component props
 * @param {Function} props.onClick - Click handler
 * @param {boolean} props.disabled - Disabled state
 */
const GenerateButton = ({ onClick, disabled }) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="generate-btn"
    >
      Generate
    </button>
  );
};

// ❌ BAD

function btn(p) {
  // no JSDoc
  // unclear naming
  // no prop validation
  return <button onClick={p.f}>{p.t}</button>;
}
```

### قوانین JS/React:

```
✅ DO:
- JSDoc comments
- PropTypes یا TypeScript
- Functional components
- Hooks properly
- Clear naming

❌ DON'T:
- Class components (unless needed)
- Inline styles (use CSS/Tailwind)
- Console.logs در production
```

---

## 📚 استانداردهای Documentation

### Markdown Files:

```markdown
# ✅ GOOD

## واضح و Structured

### سرتیتر معنادار

متن واضح با:
- لیست‌های مرتب
- مثال‌های کد
- لینک‌های درست

\`\`\`python
# کد با syntax highlighting
def example():
    pass
\`\`\`

---

# ❌ BAD

سرتیتر بد
متن بدون ساختار
بدون مثال
بدون فرمت
```

### Blueprint Files:

```
استاندارد Blueprint:

1. عنوان واضح
2. Purpose statement
3. Input/Output مشخص
4. Dependencies لیست شده
5. مثال‌های عملی
6. Exit criteria

بدون این‌ها → رد می‌شه
```

---

## 🔍 فرآیند Review

### چی چک می‌شه؟

#### 1. Architecture Compliance

```
□ Zone Boundaries رعایت شده؟
□ Core دست نخورده؟
□ معماری Layered حفظ شده؟
□ Dependencies درست؟
```

#### 2. Code Quality

```
□ Tests passing؟
□ Code formatted؟
□ No warnings؟
□ Type hints کامل؟
□ Docstrings کامل؟
```

#### 3. Documentation

```
□ CHANGELOG updated؟
□ README updated (اگه لازمه)؟
□ Blueprint updated (اگه لازمه)؟
□ Comments واضح؟
```

#### 4. Functionality

```
□ کار می‌کنه؟
□ Edge cases covered؟
□ Error handling درست؟
□ Performance OK؟
```

---

### زمان Review:

```
معمولاً:
- Small changes: 1-2 روز
- Medium changes: 3-5 روز  
- Large changes: 1 هفته+

اگه urgent هست:
- بگو در PR description
- ولی urgent = کیفیت پایین‌تر نیست!
```

---

### Feedback:

```
ممکنه بگیم:
- "Please fix X" → باید Fix بشه
- "Consider Y" → پیشنهاد (optional)
- "Question: Z" → توضیح بده

همیشه:
- محترمانه هست
- سازنده است
- با دلیل

اگه disagreement داشتی:
- توضیح بده چرا
- دلیل بیار
- بحث سازنده
```

---

## ⚠️ نکات مهم

### 1. تغییرات بزرگ

```
اگه می‌خوای تغییر بزرگ بدی:

1. اول Issue باز کن
2. توضیح بده چی می‌خوای
3. منتظر Approval بمون
4. بعد شروع کن

چرا؟
- شاید راه بهتری باشه
- شاید با Philosophy سازگار نباشه
- شاید داره توسط کس دیگه‌ای کار میشه
```

---

### 2. Breaking Changes

```
❌ NEVER:
تغییری که API رو می‌شکنه
بدون discussion و approval

اگه لازمه:
1. Issue + Discussion
2. Migration path بده
3. Deprecation period
4. Documentation کامل
```

---

### 3. تست‌ها

```
هر PR باید:
□ Tests برای کد جدید
□ Tests برای bug fix
□ Edge cases covered
□ همه Tests passing

بدون Test = رد می‌شه
(جز Documentation-only PRs)
```

---

### 4. Philosophy Alignment

```
قبل از PR بپرس:

"آیا این تغییر با Philosophy پروژه سازگاره؟"

اگه:
- Control انسانی کم میشه → ❌
- Complexity بی‌دلیل اضافه میشه → ❌
- Scope creep هست → ❌
- معماری می‌شکنه → ❌

پس: این کار رو نکن!
```

---

## 🎁 انواع مشارکت

### می‌تونی کمک کنی با:

#### 1. Code

```
- Bug fixes
- تست‌های بیشتر
- بهبود Performance
- Refactoring
```

#### 2. Documentation

```
- رفع typo ها
- اضافه کردن مثال‌ها
- ترجمه
- بهبود Clarity
```

#### 3. Review

```
- Review کردن PR های دیگران
- Testing
- Feedback دادن
```

#### 4. Ideas

```
- پیشنهاد فیچر (در Issues)
- گزارش Bug
- بهبود Architecture
- سوال پرسیدن (بحث ایجاد می‌کنه)
```

---

## 🚫 کارهای ممنوع

```
❌ این کارها رو نکن:

1. تغییر Core بدون اجازه
2. شکستن Zone Boundaries
3. Commit بدون Test
4. Push بدون Format
5. PR بدون Description
6. Ignore کردن Review feedback
7. Copy/paste کد بدون لایسنس
8. اضافه کردن Dependencies بدون توجیه
9. تغییر Philosophy
10. Disrespect به Contributors

این کارها → PR رد می‌شه یا حتی Ban
```

---

## 📞 سوالات؟

### اگه سوالی داری:

```
1. بخون: این فایل (CONTRIBUTING.md) دوباره
2. بخون: QUICK_START.md
3. بخون: Master_Blueprint_Index_v2.txt
4. بپرس: در Discussions
5. Open Issue: با tag "question"
```

### اگه گیر کردی:

```
- بپرس! سوال بد وجود نداره
- توضیح بده کجا گیر کردی
- چی امتحان کردی
- چی نشد
```

---

## ✨ Code of Conduct

### اصول رفتاری:

```
✅ باش:
- محترم
- صبور
- سازنده
- کمک‌کننده
- منصف

❌ نباش:
- توهین‌آمیز
- Spam
- غیرحرفه‌ای
- سیاسی (بی‌ربط به پروژه)
```

### نقض:

```
نقض Code of Conduct:
→ اخطار
→ Temporary ban
→ Permanent ban

بستگی به شدت دارد
```

---

## 🎓 نکات برای Contributor های جدید

### برای اولین PR:

```
1. شروع کن با چیز کوچیک:
   - رفع typo
   - اضافه کردن Test
   - بهبود Documentation

2. بخون خوب:
   - QUICK_START.md
   - این فایل
   - Master Blueprint Index

3. یاد بگیر:
   - ساختار پروژه
   - Philosophy
   - Naming conventions

4. بپرس:
   - قبل از شروع
   - وقتی گیر کردی
   - قبل از PR
```

---

## 📜 لایسنس

```
با contribute کردن، موافقت می‌کنی که:
- کدت تحت لایسنس پروژه منتشر بشه
- Owner می‌تونه استفاده کنه
- تغییر بده اگه لازم باشه

اگه موافق نیستی:
→ Contribute نکن
```

---

## 🙏 تشکر

```
ممنون که:
- این رو خوندی
- می‌خوای کمک کنی
- Philosophy رو محترم می‌شماری
- وقت گذاشتی

هر مشارکتی، کوچیک یا بزرگ،
ارزشمنده! 💚
```

---

## 🔗 لینک‌های مفید

```
📚 Documentation:
- Master Blueprint Index
- QUICK_START.md
- AI_Coding_Prompt_Template

⚖️ Governance:
- Pre_Build_Philosophy_Readiness_Master
- AI_Governance_Master
- Architecture_Philosophy

🚀 Implementation:
- Sprint_1_Task_List
- Execution_Backlog_Master
- Feature_Gating_Master
```

---

📅 Last Updated: 2026-02-08  
📝 Version: 1.0  
✅ Status: Active

**موفق باشی! 🚀**

---

## Quick Checklist برای PR:

```
قبل از Submit:

□ Branch از main جدا شده
□ Commit messages واضح
□ Code formatted (black/prettier)
□ Tests passing
□ No warnings
□ Documentation updated
□ CHANGELOG updated
□ Self-review انجام شده
□ Philosophy aligned
□ Zone boundaries respected

همه ✓ → Submit PR
یکی ✗ → Fix کن اول
```
