/**
 * Story Wizard - Example Implementation
 * =====================================
 * 
 * این یک نمونه ساده از Story Wizard است که نشان می‌دهد:
 * - چگونه ورودی کاربر را دریافت کنیم
 * - چگونه Validation انجام دهیم
 * - چگونه Story Context Object بسازیم
 * 
 * نکته: این کد ساده‌سازی شده است و برای Production نیاز به تکمیل دارد.
 * 
 * مرجع: 02-Blueprint_StoryWizard_FA.txt
 */

// ================================================================
// Data Structures
// ================================================================

const STORY_TYPES = {
  NARRATIVE: "Narrative",
  CONCEPTUAL: "Conceptual",
  VISUAL_ONLY: "Visual-only",
  EXPERIMENTAL: "Experimental"
};

const GENRES = {
  ACTION: "Action",
  DRAMA: "Drama",
  SCI_FI: "Sci-Fi",
  FANTASY: "Fantasy",
  HORROR: "Horror",
  ROMANCE: "Romance",
  DOCUMENTARY: "Documentary",
  EXPERIMENTAL: "Experimental"
};

const MOODS = {
  CALM: "Calm",
  DARK: "Dark",
  EPIC: "Epic",
  EMOTIONAL: "Emotional",
  MYSTERIOUS: "Mysterious",
  TENSE: "Tense",
  HOPEFUL: "Hopeful",
  MELANCHOLIC: "Melancholic"
};

// ================================================================
// Story Wizard Class
// ================================================================

class StoryWizard {
  constructor() {
    this.state = {
      currentStep: 1,
      data: {}
    };
  }

  /**
   * Step 1: Story Type
   */
  setStoryType(type) {
    if (!Object.values(STORY_TYPES).includes(type)) {
      throw new Error(`Invalid story type: ${type}`);
    }
    this.state.data.story_type = type;
    this.state.currentStep = 2;
    return this.getNextStep();
  }

  /**
   * Step 2: Genre
   */
  setGenre(genre) {
    // می‌تواند یک یا چند ژانر باشد
    const genres = Array.isArray(genre) ? genre : [genre];
    
    for (const g of genres) {
      if (!Object.values(GENRES).includes(g)) {
        throw new Error(`Invalid genre: ${g}`);
      }
    }
    
    this.state.data.genre = genres.length === 1 ? genres[0] : genres;
    this.state.currentStep = 3;
    return this.getNextStep();
  }

  /**
   * Step 3: Mood
   */
  setMood(primary, secondary = null) {
    if (!Object.values(MOODS).includes(primary)) {
      throw new Error(`Invalid primary mood: ${primary}`);
    }
    
    if (secondary && !Object.values(MOODS).includes(secondary)) {
      throw new Error(`Invalid secondary mood: ${secondary}`);
    }

    this.state.data.mood = {
      primary: primary,
      secondary: secondary
    };

    // Smart validation
    const warnings = this.checkMoodConsistency();
    
    this.state.currentStep = 4;
    return { nextStep: this.getNextStep(), warnings };
  }

  /**
   * Step 4: Narrative Intensity
   */
  setNarrativeIntensity(intensity) {
    const validIntensities = ["Minimal", "Moderate", "High", "Extreme"];
    if (!validIntensities.includes(intensity)) {
      throw new Error(`Invalid narrative intensity: ${intensity}`);
    }
    
    this.state.data.narrative_intensity = intensity;
    this.state.currentStep = 5;
    return this.getNextStep();
  }

  /**
   * Step 5: Visual Intent
   */
  setVisualIntent(intent) {
    const validIntents = ["Realistic", "Cinematic", "Stylized", "Artistic", "Abstract"];
    if (!validIntents.includes(intent)) {
      throw new Error(`Invalid visual intent: ${intent}`);
    }
    
    this.state.data.visual_intent = intent;
    this.state.currentStep = 6; // Complete
    return null; // No next step
  }

  /**
   * Check mood consistency with genre
   */
  checkMoodConsistency() {
    const warnings = [];
    const genre = Array.isArray(this.state.data.genre) 
      ? this.state.data.genre[0] 
      : this.state.data.genre;
    const mood = this.state.data.mood.primary;

    // بررسی ترکیبات غیرمعمول
    if (genre === GENRES.HORROR && mood === MOODS.HOPEFUL) {
      warnings.push("ترکیب Horror + Hopeful غیرمعمول است - آیا مطمئن هستید؟");
    }

    if (genre === GENRES.ROMANCE && mood === MOODS.DARK) {
      warnings.push("ترکیب Romance + Dark غیرمعمول است (مگر Dark Romance)");
    }

    return warnings;
  }

  /**
   * Get current step description
   */
  getNextStep() {
    const steps = {
      1: { name: "Story Type", question: "پروژه شما چه نوع داستانی دارد؟", options: STORY_TYPES },
      2: { name: "Genre", question: "ژانر پروژه چیست؟", options: GENRES },
      3: { name: "Mood", question: "حال و هوای کلی پروژه چگونه است؟", options: MOODS },
      4: { name: "Narrative Intensity", question: "شدت روایت چقدر باشد؟", options: ["Minimal", "Moderate", "High", "Extreme"] },
      5: { name: "Visual Intent", question: "هدف بصری شما چیست؟", options: ["Realistic", "Cinematic", "Stylized", "Artistic", "Abstract"] }
    };

    return steps[this.state.currentStep] || null;
  }

  /**
   * Complete wizard and generate Story Context Object
   */
  complete() {
    // Validation
    if (this.state.currentStep !== 6) {
      throw new Error("Wizard is not complete. Please complete all steps.");
    }

    const required = ['story_type', 'genre', 'mood', 'narrative_intensity', 'visual_intent'];
    for (const field of required) {
      if (!this.state.data[field]) {
        throw new Error(`Missing required field: ${field}`);
      }
    }

    // Generate Story Context Object
    const storyContext = {
      story_context: {
        ...this.state.data,
        metadata: {
          created_at: new Date().toISOString(),
          wizard_version: "2.0",
          completion_status: "complete"
        }
      }
    };

    return storyContext;
  }

  /**
   * Get current state (for saving/resuming)
   */
  getState() {
    return JSON.parse(JSON.stringify(this.state));
  }

  /**
   * Restore state (for resuming)
   */
  setState(state) {
    this.state = JSON.parse(JSON.stringify(state));
  }
}

// ================================================================
// Example Usage
// ================================================================

function exampleUsage() {
  console.log("🎬 Story Wizard Example");
  console.log("=" .repeat(50));

  try {
    // Create wizard
    const wizard = new StoryWizard();

    // Step 1: Story Type
    console.log("\n📝 Step 1: Story Type");
    wizard.setStoryType(STORY_TYPES.NARRATIVE);
    console.log("✓ Set to: Narrative");

    // Step 2: Genre
    console.log("\n📝 Step 2: Genre");
    wizard.setGenre([GENRES.SCI_FI, GENRES.DRAMA]); // Hybrid
    console.log("✓ Set to: Sci-Fi + Drama");

    // Step 3: Mood
    console.log("\n📝 Step 3: Mood");
    const moodResult = wizard.setMood(MOODS.DARK, MOODS.MYSTERIOUS);
    console.log("✓ Set to: Dark (primary), Mysterious (secondary)");
    if (moodResult.warnings.length > 0) {
      console.log("⚠️  Warnings:", moodResult.warnings);
    }

    // Step 4: Narrative Intensity
    console.log("\n📝 Step 4: Narrative Intensity");
    wizard.setNarrativeIntensity("High");
    console.log("✓ Set to: High");

    // Step 5: Visual Intent
    console.log("\n📝 Step 5: Visual Intent");
    wizard.setVisualIntent("Cinematic");
    console.log("✓ Set to: Cinematic");

    // Complete
    console.log("\n🎉 Wizard Complete!");
    const storyContext = wizard.complete();

    console.log("\n📦 Story Context Object:");
    console.log(JSON.stringify(storyContext, null, 2));

  } catch (error) {
    console.error("\n❌ Error:", error.message);
  }
}

// ================================================================
// Quick Mode Example
// ================================================================

function quickModeExample() {
  console.log("\n\n⚡ Quick Mode Example");
  console.log("=" .repeat(50));

  try {
    const wizard = new StoryWizard();

    // تنظیم سریع همه فیلدها
    wizard.setStoryType(STORY_TYPES.CONCEPTUAL);
    wizard.setGenre(GENRES.EXPERIMENTAL);
    wizard.setMood(MOODS.MYSTERIOUS);
    wizard.setNarrativeIntensity("Minimal");
    wizard.setVisualIntent("Abstract");

    const result = wizard.complete();
    
    console.log("\n✓ Quick Mode Complete!");
    console.log("Story Type:", result.story_context.story_type);
    console.log("Genre:", result.story_context.genre);
    console.log("Mood:", result.story_context.mood.primary);
  } catch (error) {
    console.error("❌ Error:", error.message);
  }
}

// ================================================================
// Run Examples
// ================================================================

if (require.main === module) {
  exampleUsage();
  quickModeExample();
}

// Export for use in other modules
module.exports = {
  StoryWizard,
  STORY_TYPES,
  GENRES,
  MOODS
};
