/**
 * Data Schemas - Example Definitions
 * ===================================
 * 
 * این فایل نمونه‌هایی از Schema ها و Type Definition ها را نشان می‌دهد
 * 
 * مرجع: 29-Blueprint_ProjectDataSchema_FA.txt
 */

// ================================================================
// Type Definitions (TypeScript-like comments)
// ================================================================

/**
 * @typedef {Object} StoryContextObject
 * @property {string} story_type - "Narrative" | "Conceptual" | "Visual-only" | "Experimental"
 * @property {string|string[]} genre - ژانر یا ژانرهای ترکیبی
 * @property {MoodObject} mood - حال و هوای پروژه
 * @property {string} narrative_intensity - "Minimal" | "Moderate" | "High" | "Extreme"
 * @property {string} visual_intent - "Realistic" | "Cinematic" | "Stylized" | "Artistic" | "Abstract"
 * @property {MetadataObject} metadata - اطلاعات متا
 */

/**
 * @typedef {Object} MoodObject
 * @property {string} primary - Mood اصلی
 * @property {string} [secondary] - Mood فرعی (اختیاری)
 */

/**
 * @typedef {Object} MetadataObject
 * @property {string} created_at - ISO 8601 timestamp
 * @property {string} wizard_version - نسخه wizard
 * @property {string} completion_status - "complete" | "partial"
 */

// ================================================================
// Schema Validators
// ================================================================

class SchemaValidator {
  /**
   * Validate Story Context Object
   */
  static validateStoryContext(obj) {
    const errors = [];

    // Required fields
    const required = ['story_type', 'genre', 'mood', 'narrative_intensity', 'visual_intent'];
    for (const field of required) {
      if (!obj[field]) {
        errors.push(`Missing required field: ${field}`);
      }
    }

    // Validate story_type
    const validStoryTypes = ['Narrative', 'Conceptual', 'Visual-only', 'Experimental'];
    if (obj.story_type && !validStoryTypes.includes(obj.story_type)) {
      errors.push(`Invalid story_type: ${obj.story_type}`);
    }

    // Validate genre
    const validGenres = ['Action', 'Drama', 'Sci-Fi', 'Fantasy', 'Horror', 'Romance', 'Documentary', 'Experimental'];
    const genres = Array.isArray(obj.genre) ? obj.genre : [obj.genre];
    for (const genre of genres) {
      if (!validGenres.includes(genre)) {
        errors.push(`Invalid genre: ${genre}`);
      }
    }

    // Validate mood
    if (obj.mood) {
      if (!obj.mood.primary) {
        errors.push('mood.primary is required');
      }
      
      const validMoods = ['Calm', 'Dark', 'Epic', 'Emotional', 'Mysterious', 'Tense', 'Hopeful', 'Melancholic'];
      if (obj.mood.primary && !validMoods.includes(obj.mood.primary)) {
        errors.push(`Invalid mood.primary: ${obj.mood.primary}`);
      }
    }

    return {
      valid: errors.length === 0,
      errors: errors
    };
  }

  /**
   * Validate Scene Object
   */
  static validateScene(obj) {
    const errors = [];

    if (!obj.scene_id) errors.push('Missing scene_id');
    if (!obj.title) errors.push('Missing title');
    if (!obj.location) errors.push('Missing location');
    if (!obj.time_of_day) errors.push('Missing time_of_day');

    return {
      valid: errors.length === 0,
      errors: errors
    };
  }

  /**
   * Validate Shot Object
   */
  static validateShot(obj) {
    const errors = [];

    if (!obj.shot_id) errors.push('Missing shot_id');
    if (!obj.scene_id) errors.push('Missing scene_id');
    if (!obj.shot_type) errors.push('Missing shot_type');

    // Validate shot_type
    const validTypes = ['wide', 'medium', 'closeup', 'extreme_closeup'];
    if (obj.shot_type && !validTypes.includes(obj.shot_type)) {
      errors.push(`Invalid shot_type: ${obj.shot_type}`);
    }

    return {
      valid: errors.length === 0,
      errors: errors
    };
  }

  /**
   * Validate Camera Configuration
   */
  static validateCamera(obj) {
    const errors = [];

    // Validate lens
    if (obj.lens) {
      if (typeof obj.lens !== 'number') {
        errors.push('lens must be a number');
      } else if (obj.lens < 14 || obj.lens > 200) {
        errors.push('lens must be between 14mm and 200mm');
      }
    }

    // Validate aperture
    if (obj.aperture) {
      if (typeof obj.aperture !== 'number') {
        errors.push('aperture must be a number');
      } else if (obj.aperture < 1.2 || obj.aperture > 22) {
        errors.push('aperture must be between f/1.2 and f/22');
      }
    }

    return {
      valid: errors.length === 0,
      errors: errors
    };
  }
}

// ================================================================
// Example Data Objects
// ================================================================

const exampleStoryContext = {
  story_type: "Narrative",
  genre: ["Sci-Fi", "Drama"],
  mood: {
    primary: "Dark",
    secondary: "Mysterious"
  },
  narrative_intensity: "High",
  visual_intent: "Cinematic",
  metadata: {
    created_at: "2026-02-10T12:00:00Z",
    wizard_version: "2.0",
    completion_status: "complete"
  }
};

const exampleScene = {
  scene_id: "scene_001",
  title: "Opening Scene",
  description: "A lone spaceship drifts in the void of space",
  location: "Deep Space",
  time_of_day: "Night",
  atmosphere: {
    mood: "mysterious",
    tension_level: "medium"
  },
  shots: ["shot_001", "shot_002", "shot_003"]
};

const exampleShot = {
  shot_id: "shot_001",
  scene_id: "scene_001",
  shot_type: "wide",
  duration: 5.5,
  description: "Establishing shot of the spaceship",
  camera: {
    angle: "low angle",
    movement: "slow dolly in",
    lens: 24,
    aperture: 2.8,
    depth_of_field: "deep"
  },
  lighting: {
    type: "dramatic",
    direction: "side",
    intensity: "low",
    color_temperature: 5500
  },
  subjects: ["spaceship"],
  motion_intensity: "slow"
};

const exampleCharacter = {
  character_id: "char_001",
  name: "Captain Rodriguez",
  description: "middle-aged man, weathered face, short gray hair",
  base_appearance: "hispanic male, 50 years old, muscular build",
  outfits: [
    {
      id: "outfit_01",
      description: "space suit, white with blue trim, NASA-style patches"
    },
    {
      id: "outfit_02",
      description: "casual uniform, black tactical shirt, cargo pants"
    }
  ],
  expressions: [
    {
      id: "exp_determined",
      description: "determined expression, jaw set, focused eyes"
    },
    {
      id: "exp_worried",
      description: "worried look, furrowed brow, tired eyes"
    }
  ]
};

const examplePromptOutput = {
  prompt: "A lone spaceship drifting in deep space, dramatic side lighting, " +
          "cinematic wide shot, 24mm lens, f/2.8, deep depth of field, " +
          "mysterious atmosphere, ultra detailed, 8k, photorealistic",
  negative_prompt: "blurry, low quality, distorted, watermark, text",
  target_model: "Midjourney",
  parameters: {
    aspect_ratio: "16:9",
    stylize: 750,
    chaos: 0,
    version: "6"
  },
  token_count: 32,
  estimated_cost: "$0.0032",
  metadata: {
    generated_at: "2026-02-10T12:05:00Z",
    shot_id: "shot_001",
    scene_id: "scene_001"
  }
};

// ================================================================
// Schema Factory
// ================================================================

class SchemaFactory {
  /**
   * Create empty Story Context
   */
  static createStoryContext() {
    return {
      story_type: null,
      genre: null,
      mood: {
        primary: null,
        secondary: null
      },
      narrative_intensity: "Moderate", // default
      visual_intent: "Cinematic", // default
      metadata: {
        created_at: new Date().toISOString(),
        wizard_version: "2.0",
        completion_status: "partial"
      }
    };
  }

  /**
   * Create empty Scene
   */
  static createScene(sceneId, title) {
    return {
      scene_id: sceneId,
      title: title,
      description: "",
      location: "",
      time_of_day: "",
      atmosphere: {
        mood: "",
        tension_level: "medium"
      },
      shots: [],
      metadata: {
        created_at: new Date().toISOString(),
        duration: 0
      }
    };
  }

  /**
   * Create empty Shot
   */
  static createShot(shotId, sceneId) {
    return {
      shot_id: shotId,
      scene_id: sceneId,
      shot_type: "medium",
      duration: 3.0,
      description: "",
      camera: {
        angle: "eye level",
        movement: "static",
        lens: 50,
        aperture: 2.8,
        depth_of_field: "medium"
      },
      lighting: {
        type: "natural",
        direction: "front",
        intensity: "medium"
      },
      subjects: [],
      motion_intensity: "normal"
    };
  }
}

// ================================================================
// Example Usage
// ================================================================

function demonstrateValidation() {
  console.log("✅ Schema Validation Examples");
  console.log("=" .repeat(60));

  // Valid Story Context
  console.log("\n📝 Validating Story Context (Valid):");
  const result1 = SchemaValidator.validateStoryContext(exampleStoryContext);
  console.log(result1.valid ? "✓ Valid" : "✗ Invalid");
  if (result1.errors.length > 0) {
    console.log("Errors:", result1.errors);
  }

  // Invalid Story Context
  console.log("\n📝 Validating Story Context (Invalid):");
  const invalidContext = { story_type: "Invalid" };
  const result2 = SchemaValidator.validateStoryContext(invalidContext);
  console.log(result2.valid ? "✓ Valid" : "✗ Invalid");
  if (result2.errors.length > 0) {
    console.log("Errors:");
    result2.errors.forEach(err => console.log(`  - ${err}`));
  }

  // Valid Shot
  console.log("\n📝 Validating Shot (Valid):");
  const result3 = SchemaValidator.validateShot(exampleShot);
  console.log(result3.valid ? "✓ Valid" : "✗ Invalid");

  // Camera Validation
  console.log("\n📝 Validating Camera (Valid):");
  const result4 = SchemaValidator.validateCamera(exampleShot.camera);
  console.log(result4.valid ? "✓ Valid" : "✗ Invalid");
}

function demonstrateFactory() {
  console.log("\n\n🏭 Schema Factory Examples");
  console.log("=" .repeat(60));

  // Create new Story Context
  console.log("\n📝 New Story Context:");
  const newContext = SchemaFactory.createStoryContext();
  console.log(JSON.stringify(newContext, null, 2));

  // Create new Scene
  console.log("\n📝 New Scene:");
  const newScene = SchemaFactory.createScene("scene_002", "Second Scene");
  console.log(JSON.stringify(newScene, null, 2));
}

function displayExamples() {
  console.log("\n\n📋 Example Data Objects");
  console.log("=" .repeat(60));

  console.log("\n1️⃣ Story Context:");
  console.log(JSON.stringify(exampleStoryContext, null, 2));

  console.log("\n2️⃣ Scene:");
  console.log(JSON.stringify(exampleScene, null, 2));

  console.log("\n3️⃣ Shot:");
  console.log(JSON.stringify(exampleShot, null, 2));

  console.log("\n4️⃣ Character:");
  console.log(JSON.stringify(exampleCharacter, null, 2));

  console.log("\n5️⃣ Prompt Output:");
  console.log(JSON.stringify(examplePromptOutput, null, 2));
}

// ================================================================
// Run Examples
// ================================================================

if (require.main === module) {
  demonstrateValidation();
  demonstrateFactory();
  displayExamples();
}

// Export
module.exports = {
  SchemaValidator,
  SchemaFactory,
  exampleStoryContext,
  exampleScene,
  exampleShot,
  exampleCharacter,
  examplePromptOutput
};
