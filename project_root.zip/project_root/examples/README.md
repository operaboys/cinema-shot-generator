# Examples - نمونه‌های پیاده‌سازی

این پوشه شامل نمونه کدهای ساده و کاربردی برای شروع پیاده‌سازی پروژه است.

## 📋 محتویات

### 1. Story Wizard Example
**فایل:** `example_story_wizard.js`
- پیاده‌سازی ساده Story Wizard
- نمونه Validation
- نمونه Output

### 2. Prompt Engineering Example
**فایل:** `example_prompt_engineering.js`
- ترکیب داده‌ها و تولید پرامپت
- نمونه Template Engine
- کار با Token Cost

### 3. Data Schema Example
**فایل:** `example_data_schemas.js`
- تعریف Schema ها
- نمونه Validation
- Type Definitions (TypeScript-like)

### 4. Python Utility Example
**فایل:** `example_utils.py`
- توابع کمکی Python
- File handling
- JSON processing

## 🎯 هدف

این نمونه‌ها:
- ✅ **نقطه شروع** برای Implementation هستند
- ✅ **الگوها** (Patterns) را نشان می‌دهند
- ✅ **Best Practices** را دنبال می‌کنند
- ❌ **کد Production-Ready نیستند** (فقط نمونه)

## ⚠️ توجه

- این کدها ساده‌سازی شده‌اند
- برای Production نیاز به تکمیل دارند
- فقط برای یادگیری و الگوبرداری هستند

## 🚀 استفاده

```bash
# JavaScript Examples
node example_story_wizard.js
node example_prompt_engineering.js
node example_data_schemas.js

# Python Example
python3 example_utils.py
```

## 📚 مراجع

برای جزئیات بیشتر، Blueprint های مربوطه را مطالعه کنید:
- 02-Blueprint_StoryWizard_FA.txt
- 21-Blueprint_PromptEngineering_FA.txt
- 29-Blueprint_ProjectDataSchema_FA.txt

---

**نسخه:** 1.0  
**تاریخ:** 2026-02-10
