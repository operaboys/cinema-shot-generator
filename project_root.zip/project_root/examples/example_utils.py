#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Python Utilities - Example Implementation
==========================================

این فایل شامل توابع کمکی Python برای:
- کار با فایل‌ها
- پردازش JSON
- Validation
- File handling

مرجع: Blueprint های مختلف
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Union
from datetime import datetime
import re


# ================================================================
# File Utilities
# ================================================================

class FileUtils:
    """توابع کمکی برای کار با فایل"""
    
    @staticmethod
    def read_json(file_path: str) -> Dict:
        """خواندن فایل JSON"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"File not found: {file_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in {file_path}: {e}")
    
    @staticmethod
    def write_json(file_path: str, data: Dict, indent: int = 2):
        """نوشتن فایل JSON"""
        try:
            # ایجاد پوشه اگر وجود ندارد
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=indent)
        except Exception as e:
            raise IOError(f"Error writing to {file_path}: {e}")
    
    @staticmethod
    def read_text(file_path: str) -> str:
        """خواندن فایل متنی"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            raise FileNotFoundError(f"File not found: {file_path}")
    
    @staticmethod
    def write_text(file_path: str, content: str):
        """نوشتن فایل متنی"""
        try:
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
        except Exception as e:
            raise IOError(f"Error writing to {file_path}: {e}")
    
    @staticmethod
    def list_files(directory: str, pattern: str = "*") -> List[Path]:
        """لیست فایل‌های یک پوشه"""
        path = Path(directory)
        if not path.exists():
            raise FileNotFoundError(f"Directory not found: {directory}")
        
        return list(path.glob(pattern))


# ================================================================
# Validation Utilities
# ================================================================

class ValidationUtils:
    """توابع کمکی برای Validation"""
    
    @staticmethod
    def validate_story_context(data: Dict) -> tuple[bool, List[str]]:
        """Validate Story Context Object"""
        errors = []
        
        # Required fields
        required = ['story_type', 'genre', 'mood', 'narrative_intensity', 'visual_intent']
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: {field}")
        
        # Validate story_type
        valid_types = ['Narrative', 'Conceptual', 'Visual-only', 'Experimental']
        if 'story_type' in data and data['story_type'] not in valid_types:
            errors.append(f"Invalid story_type: {data['story_type']}")
        
        # Validate genre
        valid_genres = ['Action', 'Drama', 'Sci-Fi', 'Fantasy', 'Horror', 
                       'Romance', 'Documentary', 'Experimental']
        if 'genre' in data:
            genres = data['genre'] if isinstance(data['genre'], list) else [data['genre']]
            for genre in genres:
                if genre not in valid_genres:
                    errors.append(f"Invalid genre: {genre}")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_required_fields(data: Dict, required: List[str]) -> tuple[bool, List[str]]:
        """بررسی وجود فیلدهای الزامی"""
        errors = []
        for field in required:
            if field not in data or data[field] is None:
                errors.append(f"Missing required field: {field}")
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_enum(value: str, valid_values: List[str], field_name: str) -> tuple[bool, str]:
        """بررسی مقدار enum"""
        if value not in valid_values:
            return False, f"Invalid {field_name}: {value}. Valid values: {', '.join(valid_values)}"
        return True, ""


# ================================================================
# String Utilities
# ================================================================

class StringUtils:
    """توابع کمکی برای کار با رشته‌ها"""
    
    @staticmethod
    def to_snake_case(text: str) -> str:
        """تبدیل به snake_case"""
        # CamelCase → snake_case
        text = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', text)
        text = re.sub('([a-z0-9])([A-Z])', r'\1_\2', text)
        return text.lower()
    
    @staticmethod
    def to_camel_case(text: str) -> str:
        """تبدیل به camelCase"""
        components = text.split('_')
        return components[0] + ''.join(x.title() for x in components[1:])
    
    @staticmethod
    def to_pascal_case(text: str) -> str:
        """تبدیل به PascalCase"""
        return ''.join(x.title() for x in text.split('_'))
    
    @staticmethod
    def clean_whitespace(text: str) -> str:
        """پاکسازی فضاهای خالی اضافی"""
        # حذف فضاهای خالی ابتدا و انتها
        text = text.strip()
        # تبدیل چند فضای خالی به یک فضا
        text = re.sub(r'\s+', ' ', text)
        return text
    
    @staticmethod
    def truncate(text: str, max_length: int, suffix: str = "...") -> str:
        """کوتاه کردن متن"""
        if len(text) <= max_length:
            return text
        return text[:max_length - len(suffix)] + suffix


# ================================================================
# Token Utilities
# ================================================================

class TokenUtils:
    """توابع کمکی برای کار با Token"""
    
    @staticmethod
    def estimate_tokens(text: str) -> int:
        """تخمین تعداد Token ها (ساده)"""
        # تخمین: هر کلمه تقریباً 1.3 token
        words = len(text.split())
        return int(words * 1.3)
    
    @staticmethod
    def calculate_cost(token_count: int, cost_per_token: float = 0.0001) -> float:
        """محاسبه هزینه"""
        return token_count * cost_per_token
    
    @staticmethod
    def optimize_prompt(prompt: str, max_tokens: int = 75) -> str:
        """بهینه‌سازی پرامپت برای حد مجاز Token"""
        tokens = TokenUtils.estimate_tokens(prompt)
        
        if tokens <= max_tokens:
            return prompt
        
        # کوتاه کردن متن
        words = prompt.split()
        target_words = int(max_tokens / 1.3)
        
        if len(words) > target_words:
            return ' '.join(words[:target_words])
        
        return prompt


# ================================================================
# Data Processing Utilities
# ================================================================

class DataProcessor:
    """توابع پردازش داده"""
    
    @staticmethod
    def merge_objects(*objects: Dict) -> Dict:
        """ترکیب چند dictionary"""
        result = {}
        for obj in objects:
            result.update(obj)
        return result
    
    @staticmethod
    def filter_none(data: Dict) -> Dict:
        """حذف فیلدهای None"""
        return {k: v for k, v in data.items() if v is not None}
    
    @staticmethod
    def flatten_dict(data: Dict, parent_key: str = '', sep: str = '.') -> Dict:
        """تبدیل dictionary تودرتو به یک سطح"""
        items = []
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(DataProcessor.flatten_dict(v, new_key, sep).items())
            else:
                items.append((new_key, v))
        return dict(items)
    
    @staticmethod
    def extract_field(data: Union[Dict, List], field_path: str, default=None):
        """استخراج فیلد از مسیر مشخص (مثلاً "user.profile.name")"""
        try:
            keys = field_path.split('.')
            result = data
            for key in keys:
                if isinstance(result, dict):
                    result = result[key]
                elif isinstance(result, list):
                    result = result[int(key)]
                else:
                    return default
            return result
        except (KeyError, IndexError, TypeError):
            return default


# ================================================================
# Example Usage
# ================================================================

def example_file_operations():
    """نمونه عملیات فایل"""
    print("📁 File Operations Example")
    print("=" * 60)
    
    # ایجاد داده نمونه
    story_context = {
        "story_type": "Narrative",
        "genre": "Sci-Fi",
        "mood": {
            "primary": "Dark",
            "secondary": "Mysterious"
        },
        "created_at": datetime.now().isoformat()
    }
    
    # نوشتن JSON
    print("\n📝 Writing JSON...")
    FileUtils.write_json("/tmp/story_context.json", story_context)
    print("✓ Written to /tmp/story_context.json")
    
    # خواندن JSON
    print("\n📖 Reading JSON...")
    loaded_data = FileUtils.read_json("/tmp/story_context.json")
    print(f"✓ Loaded: {loaded_data['story_type']}")


def example_validation():
    """نمونه Validation"""
    print("\n\n✅ Validation Example")
    print("=" * 60)
    
    # داده صحیح
    valid_data = {
        "story_type": "Narrative",
        "genre": "Sci-Fi",
        "mood": {"primary": "Dark"},
        "narrative_intensity": "High",
        "visual_intent": "Cinematic"
    }
    
    is_valid, errors = ValidationUtils.validate_story_context(valid_data)
    print(f"\n📝 Valid Data: {is_valid}")
    
    # داده نادرست
    invalid_data = {
        "story_type": "Invalid"
    }
    
    is_valid, errors = ValidationUtils.validate_story_context(invalid_data)
    print(f"\n📝 Invalid Data: {is_valid}")
    if errors:
        print("Errors:")
        for error in errors:
            print(f"  - {error}")


def example_string_operations():
    """نمونه عملیات رشته"""
    print("\n\n🔤 String Operations Example")
    print("=" * 60)
    
    print("\n📝 Case Conversions:")
    print(f"  CamelCase → snake_case: {StringUtils.to_snake_case('StoryWizard')}")
    print(f"  snake_case → camelCase: {StringUtils.to_camel_case('story_wizard')}")
    print(f"  snake_case → PascalCase: {StringUtils.to_pascal_case('story_wizard')}")
    
    print("\n📝 Cleaning:")
    dirty = "  Hello    World  "
    print(f"  Before: '{dirty}'")
    print(f"  After: '{StringUtils.clean_whitespace(dirty)}'")
    
    print("\n📝 Truncate:")
    long_text = "This is a very long text that needs to be truncated"
    print(f"  Original: {long_text}")
    print(f"  Truncated: {StringUtils.truncate(long_text, 20)}")


def example_token_operations():
    """نمونه عملیات Token"""
    print("\n\n🎫 Token Operations Example")
    print("=" * 60)
    
    prompt = "A beautiful sunset over mountains, cinematic lighting, 8k, ultra detailed"
    
    tokens = TokenUtils.estimate_tokens(prompt)
    cost = TokenUtils.calculate_cost(tokens)
    
    print(f"\n📝 Prompt: {prompt}")
    print(f"🎫 Estimated Tokens: {tokens}")
    print(f"💰 Estimated Cost: ${cost:.6f}")


def example_data_processing():
    """نمونه پردازش داده"""
    print("\n\n📊 Data Processing Example")
    print("=" * 60)
    
    # Merge objects
    obj1 = {"name": "Sara", "age": 25}
    obj2 = {"role": "Astronaut", "mission": "Mars"}
    merged = DataProcessor.merge_objects(obj1, obj2)
    print(f"\n📝 Merged: {merged}")
    
    # Filter None
    data_with_none = {"a": 1, "b": None, "c": 3}
    filtered = DataProcessor.filter_none(data_with_none)
    print(f"\n📝 Filtered: {filtered}")
    
    # Flatten dict
    nested = {
        "user": {
            "profile": {
                "name": "Sara",
                "age": 25
            }
        }
    }
    flattened = DataProcessor.flatten_dict(nested)
    print(f"\n📝 Flattened: {flattened}")
    
    # Extract field
    value = DataProcessor.extract_field(nested, "user.profile.name")
    print(f"\n📝 Extracted 'user.profile.name': {value}")


# ================================================================
# Main
# ================================================================

if __name__ == "__main__":
    print("\n" + "🐍 Python Utilities Examples".center(60))
    print("=" * 60)
    
    try:
        example_file_operations()
        example_validation()
        example_string_operations()
        example_token_operations()
        example_data_processing()
        
        print("\n" + "=" * 60)
        print("✅ All examples completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
