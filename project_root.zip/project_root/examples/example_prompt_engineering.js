/**
 * Prompt Engineering - Example Implementation
 * ============================================
 * 
 * این نمونه نشان می‌دهد:
 * - چگونه داده‌ها را ترکیب کنیم
 * - چگونه پرامپت تولید کنیم
 * - چگونه Token Cost محاسبه کنیم
 * 
 * مرجع: 21-Blueprint_PromptEngineering_FA.txt
 */

// ================================================================
// Template Engine
// ================================================================

class PromptTemplate {
  constructor(template) {
    this.template = template;
  }

  /**
   * جایگزینی متغیرها در template
   */
  render(data) {
    let result = this.template;
    
    // جایگزینی {variable} با مقادیر
    for (const [key, value] of Object.entries(data)) {
      const regex = new RegExp(`\\{${key}\\}`, 'g');
      result = result.replace(regex, value);
    }
    
    return result;
  }
}

// ================================================================
// Prompt Engineering Core
// ================================================================

class PromptEngineer {
  constructor() {
    this.templates = this.loadTemplates();
  }

  /**
   * بارگذاری template های مختلف
   */
  loadTemplates() {
    return {
      // Template برای Midjourney
      midjourney: new PromptTemplate(
        "{subject}, {style}, {lighting}, {camera}, {quality}"
      ),

      // Template برای Stable Diffusion
      stable_diffusion: new PromptTemplate(
        "{subject}, {environment}, {lighting}, {camera_angle}, " +
        "{technical_details}, {style_modifiers}, {quality_tags}"
      ),

      // Template برای Sora (video)
      sora: new PromptTemplate(
        "{scene_description}, {camera_movement}, {lighting}, " +
        "{motion_description}, {duration}, {style}"
      )
    };
  }

  /**
   * تولید پرامپت بر اساس داده‌های ورودی
   */
  generatePrompt(data, target = 'midjourney') {
    // انتخاب template مناسب
    const template = this.templates[target];
    if (!template) {
      throw new Error(`Unknown target: ${target}`);
    }

    // آماده‌سازی داده‌ها
    const promptData = this.prepareData(data, target);

    // تولید پرامپت
    let prompt = template.render(promptData);

    // پاکسازی
    prompt = this.cleanPrompt(prompt);

    return {
      prompt: prompt,
      target: target,
      token_count: this.estimateTokens(prompt),
      metadata: {
        generated_at: new Date().toISOString(),
        version: "1.0"
      }
    };
  }

  /**
   * آماده‌سازی داده‌ها بر اساس target
   */
  prepareData(data, target) {
    const prepared = {};

    // Subject
    prepared.subject = this.buildSubject(data.character, data.action);

    // Style
    prepared.style = data.visual_intent || "cinematic";

    // Lighting
    prepared.lighting = this.buildLighting(data.lighting);

    // Camera
    if (target === 'midjourney') {
      prepared.camera = this.buildCameraShort(data.camera);
    } else {
      prepared.camera_angle = data.camera?.angle || "eye level";
      prepared.technical_details = this.buildTechnicalDetails(data.camera);
    }

    // Quality
    prepared.quality = this.buildQuality(target);

    // برای Sora
    if (target === 'sora') {
      prepared.scene_description = data.scene?.description || "";
      prepared.camera_movement = data.camera?.movement || "static";
      prepared.motion_description = data.motion?.description || "";
      prepared.duration = data.duration || "5 seconds";
    }

    return prepared;
  }

  /**
   * ساخت بخش Subject
   */
  buildSubject(character, action) {
    if (!character) return "a person";
    
    let subject = character.description || character.name;
    
    if (action) {
      subject += `, ${action}`;
    }

    return subject;
  }

  /**
   * ساخت بخش Lighting
   */
  buildLighting(lighting) {
    if (!lighting) return "natural lighting";

    const parts = [];

    if (lighting.type) parts.push(lighting.type);
    if (lighting.direction) parts.push(`${lighting.direction} light`);
    if (lighting.intensity) parts.push(`${lighting.intensity} intensity`);

    return parts.join(", ") || "natural lighting";
  }

  /**
   * ساخت بخش Camera (کوتاه برای Midjourney)
   */
  buildCameraShort(camera) {
    if (!camera) return "cinematic shot";

    const parts = [];

    if (camera.shot_type) parts.push(camera.shot_type);
    if (camera.lens) parts.push(`${camera.lens}mm lens`);

    return parts.join(", ") || "cinematic shot";
  }

  /**
   * ساخت جزئیات فنی دوربین
   */
  buildTechnicalDetails(camera) {
    if (!camera) return "";

    const parts = [];

    if (camera.lens) parts.push(`${camera.lens}mm lens`);
    if (camera.aperture) parts.push(`f/${camera.aperture}`);
    if (camera.depth_of_field) parts.push(`${camera.depth_of_field} DoF`);

    return parts.join(", ");
  }

  /**
   * ساخت Quality Tags
   */
  buildQuality(target) {
    const qualityTags = {
      midjourney: "ultra detailed, 8k, photorealistic",
      stable_diffusion: "masterpiece, best quality, highly detailed",
      sora: "cinematic quality, smooth motion, professional"
    };

    return qualityTags[target] || "high quality";
  }

  /**
   * پاکسازی پرامپت
   */
  cleanPrompt(prompt) {
    // حذف فضاهای خالی اضافی
    prompt = prompt.replace(/\s+/g, ' ');
    
    // حذف کاما و نقطه‌های اضافی
    prompt = prompt.replace(/,\s*,/g, ',');
    prompt = prompt.replace(/,\s*$/g, '');
    
    // Trim
    prompt = prompt.trim();

    return prompt;
  }

  /**
   * تخمین تعداد Token ها
   */
  estimateTokens(text) {
    // تخمین ساده: هر کلمه ~1.3 token
    const words = text.split(/\s+/).length;
    return Math.ceil(words * 1.3);
  }

  /**
   * محاسبه هزینه (فرضی)
   */
  calculateCost(tokenCount, target) {
    const costPerToken = {
      midjourney: 0.0001,
      stable_diffusion: 0.00005,
      sora: 0.0002
    };

    const rate = costPerToken[target] || 0.0001;
    return (tokenCount * rate).toFixed(6);
  }
}

// ================================================================
// Negative Prompt Helper
// ================================================================

class NegativePromptHelper {
  /**
   * تولید Negative Prompt
   */
  static generate(avoidList = []) {
    const defaults = [
      "blurry",
      "low quality",
      "distorted",
      "watermark",
      "text",
      "signature"
    ];

    const combined = [...defaults, ...avoidList];
    return combined.join(", ");
  }
}

// ================================================================
// Example Usage
// ================================================================

function exampleBasic() {
  console.log("🎨 Prompt Engineering Example - Basic");
  console.log("=" .repeat(60));

  const engineer = new PromptEngineer();

  // داده‌های ورودی
  const inputData = {
    character: {
      name: "Sara",
      description: "young woman with brown hair and green eyes"
    },
    action: "walking in a forest",
    visual_intent: "cinematic",
    lighting: {
      type: "golden hour",
      direction: "side",
      intensity: "soft"
    },
    camera: {
      shot_type: "medium shot",
      lens: 50,
      aperture: 1.8,
      depth_of_field: "shallow"
    }
  };

  // تولید پرامپت برای Midjourney
  const result = engineer.generatePrompt(inputData, 'midjourney');

  console.log("\n📝 Generated Prompt:");
  console.log(result.prompt);
  console.log("\n📊 Metadata:");
  console.log(`  Target: ${result.target}`);
  console.log(`  Token Count: ${result.token_count}`);
  console.log(`  Estimated Cost: $${engineer.calculateCost(result.token_count, result.target)}`);

  // Negative Prompt
  const negativePrompt = NegativePromptHelper.generate([
    "extra fingers",
    "bad anatomy"
  ]);
  console.log("\n🚫 Negative Prompt:");
  console.log(negativePrompt);
}

function exampleSora() {
  console.log("\n\n🎬 Prompt Engineering Example - Sora (Video)");
  console.log("=" .repeat(60));

  const engineer = new PromptEngineer();

  const videoData = {
    scene: {
      description: "A lone astronaut floating in the vastness of space"
    },
    camera: {
      movement: "slow orbit around subject",
      angle: "wide angle"
    },
    lighting: {
      type: "dramatic rim lighting from distant sun"
    },
    motion: {
      description: "gentle rotation, weightless movement"
    },
    duration: "10 seconds",
    visual_intent: "epic cinematic"
  };

  const result = engineer.generatePrompt(videoData, 'sora');

  console.log("\n📝 Generated Video Prompt:");
  console.log(result.prompt);
  console.log("\n📊 Metadata:");
  console.log(`  Token Count: ${result.token_count}`);
  console.log(`  Duration: ${videoData.duration}`);
}

function exampleWeighting() {
  console.log("\n\n⚖️  Prompt Weighting Example");
  console.log("=" .repeat(60));

  // در Midjourney می‌توان با ::N وزن دهی کرد
  const weighted = [
    "beautiful sunset::2",
    "mountains::1.5",
    "lake::1",
    "trees::0.5"
  ].join(" ");

  console.log("\n📝 Weighted Prompt:");
  console.log(weighted);
  console.log("\n💡 Explanation:");
  console.log("  sunset (2x weight) > mountains (1.5x) > lake (1x) > trees (0.5x)");
}

// ================================================================
// Run Examples
// ================================================================

if (require.main === module) {
  exampleBasic();
  exampleSora();
  exampleWeighting();
}

// Export
module.exports = {
  PromptEngineer,
  PromptTemplate,
  NegativePromptHelper
};
