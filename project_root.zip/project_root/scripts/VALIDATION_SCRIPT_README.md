# Project Validation Script - راهنمای استفاده

## 📖 توضیحات

این اسکریپت برای بررسی خودکار consistency و سازگاری پروژه Cinema Shot Generation Platform طراحی شده است.

## 🎯 قابلیت‌ها

### بررسی‌های خودکار:

1. **ساختار پروژه:**
   - وجود فایل‌های الزامی
   - وجود پوشه‌های لازم
   - ساختار کلی

2. **Blueprint ها:**
   - تعداد و نام Blueprint ها
   - حضور همه 29 Blueprint مورد انتظار
   - Blueprint های اضافی یا گمشده

3. **نام‌گذاری:**
   - رعایت استانداردهای نام‌گذاری
   - prefix های عددی صحیح
   - فرمت نام فایل‌ها

4. **ساختار Blueprint ها:**
   - وجود بخش‌های الزامی (تعریف، هدف، Dependencies، ...)
   - حجم فایل (فایل‌های خیلی کوچک مشکوک هستند)
   - قابل خواندن بودن فایل

5. **Dependencies:**
   - تعریف شدن Dependencies
   - سازگاری Dependencies

6. **آمار کلی:**
   - تعداد کل فایل‌ها
   - حجم پروژه
   - توزیع فایل‌ها

## 🚀 نصب و استفاده

### پیش‌نیاز:
```bash
Python 3.7+
```

### استفاده ساده:
```bash
# اگر در پوشه Documentation هستید:
python validate_project.py

# اگر از جای دیگری می‌خواهید اجرا کنید:
python validate_project.py /path/to/Documentation
```

### خروجی:

اسکریپت دو خروجی تولید می‌کند:

1. **گزارش در Terminal:**
   - خلاصه آمار
   - لیست خطاها
   - لیست هشدارها

2. **فایل JSON:**
   - `validation_report.json`
   - شامل جزئیات کامل
   - قابل parse برای automation

## 📊 نمونه خروجی

```
======================================================================
🔍 Project Validation Script
    Cinema Shot Generation Platform
======================================================================

📁 مسیر پروژه: /path/to/Documentation

🔍 شروع بررسی پروژه...
======================================================================

📊 جمع‌آوری آمار...
📋 بررسی فایل‌های الزامی...
🔍 بررسی Blueprint ها...
📝 بررسی نام‌گذاری...
🏗️  بررسی ساختار Blueprint ها...
🔗 بررسی Dependencies...

✅ بررسی کامل شد.

======================================================================
📊 گزارش نهایی Validation
======================================================================

📈 آمار کلی:
  • تعداد کل فایل‌ها: 75
  • تعداد Blueprint ها: 29
  • تعداد مستندات: 70
  • حجم کل: 1.02 MB

🎯 خلاصه:
  • خطاها (Errors): 0
  • هشدارها (Warnings): 2
  • اطلاعات (Info): 15

⚠️  هشدارها (2):
  1. [naming] نام‌گذاری مطابق استاندارد نیست: ...
  2. [structure] بخش الزامی موجود نیست: ...

======================================================================
✅ هیچ خطای جدی پیدا نشد!
⚠️  2 هشدار وجود دارد که بهتر است بررسی شوند.
======================================================================

💾 گزارش JSON ذخیره شد: validation_report.json
```

## 🔧 سفارشی‌سازی

### اضافه کردن Validation جدید:

در کلاس `ProjectValidator`، یک متد جدید اضافه کنید:

```python
def _check_my_validation(self):
    """توضیحات"""
    print("🔍 بررسی من...")
    
    # منطق بررسی
    # ...
    
    # اضافه کردن نتیجه
    self.add_result('category', 'severity', 'message', 'file_path')
```

سپس در متد `validate_all()` فراخوانی کنید:

```python
def validate_all(self) -> ProjectStats:
    # ...
    self._check_my_validation()  # اضافه کنید
    # ...
```

### تنظیم فایل‌های مورد انتظار:

در بخش Configuration فایل، لیست‌های زیر را ویرایش کنید:

```python
EXPECTED_BLUEPRINTS = [
    # لیست Blueprint ها
]

REQUIRED_FILES = [
    # لیست فایل‌های الزامی
]

REQUIRED_SECTIONS = [
    # بخش‌های الزامی در Blueprint ها
]
```

## 📋 سطوح Severity

| سطح | معنی | Exit Code |
|-----|------|-----------|
| **error** | خطای جدی که باید برطرف شود | 1 |
| **warning** | هشدار (بهتر است بررسی شود) | 0 |
| **info** | اطلاعات (فقط گزارش) | 0 |

## 🔄 Integration با CI/CD

می‌توانید این اسکریپت را در pipeline خود استفاده کنید:

```yaml
# مثال GitHub Actions
- name: Validate Project
  run: |
    python validate_project.py Documentation/
    if [ $? -ne 0 ]; then
      echo "Validation failed!"
      exit 1
    fi
```

## 📝 فایل JSON خروجی

```json
{
  "timestamp": "2026-02-10T12:30:00",
  "project_path": "/path/to/Documentation",
  "stats": {
    "total_files": 75,
    "blueprint_count": 29,
    "doc_count": 70,
    "total_size_mb": 1.02
  },
  "summary": {
    "errors": 0,
    "warnings": 2,
    "info": 15
  },
  "errors": [],
  "warnings": [
    {
      "category": "naming",
      "message": "...",
      "file": "...",
      "line": 0
    }
  ]
}
```

## 🐛 عیب‌یابی

### مشکل: اسکریپت فایل‌ها را پیدا نمی‌کند
**راه‌حل:** مطمئن شوید مسیر صحیح را به عنوان آرگومان داده‌اید.

### مشکل: خطای encoding
**راه‌حل:** فایل‌های شما باید UTF-8 باشند. اگر نیستند، در خط 234 تغییر دهید:
```python
content = bp_file.read_text(encoding='utf-8', errors='ignore')
```

### مشکل: کند اجرا می‌شود
**راه‌حل:** برای پروژه‌های بزرگ طبیعی است. می‌توانید بخش‌های غیرضروری را غیرفعال کنید.

## 📞 پشتیبانی

برای سوالات یا مشکلات:
1. مستندات پروژه را بخوانید
2. CHANGELOG را چک کنید
3. با معمار پروژه تماس بگیرید

## 🔮 آپدیت‌های آینده

- [ ] بررسی Cross-References بین اسناد
- [ ] Validation اتوماتیک Data Flow
- [ ] تشخیص Circular Dependencies
- [ ] تولید نمودار وابستگی‌ها
- [ ] Integration با pre-commit hooks

## 📄 لایسنس

این اسکریپت بخشی از پروژه Cinema Shot Generation Platform است.

---

**نسخه:** 1.0  
**تاریخ:** 2026-02-10  
**نویسنده:** Auto-generated
