#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Project Validation Script
==========================

این اسکریپت consistency و سازگاری پروژه Cinema Shot Generation Platform را بررسی می‌کند.

نویسنده: Auto-generated
تاریخ: 2026-02-10
نسخه: 1.0

استفاده:
    python validate_project.py [path_to_Documentation]

بدون آرگومان، از مسیر فعلی استفاده می‌کند.
"""

import os
import re
import sys
import json
from pathlib import Path
from typing import Dict, List, Tuple, Set
from dataclasses import dataclass, field
from datetime import datetime


# ================================================================================
# Data Classes
# ================================================================================

@dataclass
class ValidationResult:
    """نتیجه یک بررسی"""
    category: str
    severity: str  # 'error', 'warning', 'info'
    message: str
    file_path: str = ""
    line_number: int = 0


@dataclass
class ProjectStats:
    """آمار کلی پروژه"""
    total_files: int = 0
    blueprint_count: int = 0
    doc_count: int = 0
    total_size_mb: float = 0.0
    errors: List[ValidationResult] = field(default_factory=list)
    warnings: List[ValidationResult] = field(default_factory=list)
    info: List[ValidationResult] = field(default_factory=list)


# ================================================================================
# Configuration
# ================================================================================

# Blueprint های مورد انتظار (با prefix عددی)
EXPECTED_BLUEPRINTS = [
    "02-Blueprint_StoryWizard_FA.txt",
    "03-Blueprint_HumanOverride_FA.txt",
    "04-Blueprint_DNA_Manager_FA.txt",
    "05-Blueprint_StyleMatrix_FA.txt",
    "06-Blueprint_CinematicLanguage_FA.txt",
    "07-Blueprint_SceneEngine_FA.txt",
    "08-Blueprint_BeatSheetManager_FA.txt",
    "09-Blueprint_ShotEngine_FA.txt",
    "10-Blueprint_AssetLibrary_FA.txt",
    "11-Blueprint_ReferenceImageManager_FA.txt",
    "12-Blueprint_CharacterSubjectSystem_FA.txt",
    "13-Blueprint_ValidationEngine_FA.txt",
    "14-Blueprint_LogicConflictChecker_FA.txt",
    "15-Blueprint_DependencyResolver_FA.txt",
    "16-Blueprint_CameraSystem_FA.txt",
    "17-Blueprint_MotionIntensity_FA.txt",
    "18-Blueprint_LightingSystem_FA.txt",
    "19-Blueprint_EnvironmentEngine_FA.txt",
    "20-Blueprint_AudioContextGenerator_FA.txt",
    "21-Blueprint_PromptEngineering_FA.txt",
    "22-Blueprint_PromptCleaner_FA.txt",
    "23-Blueprint_TokenCostCalculator_FA.txt",
    "24-Blueprint_StateVersioning_FA.txt",
    "25-Blueprint_OutputTargetProfiles_FA.txt",
    "26-Blueprint_OutputComposer_FA.txt",
    "27-Blueprint_BilingualSystem_FA.txt",
    "28-Blueprint_PersistenceLayer_FA.txt",
    "29-Blueprint_ProjectDataSchema_FA.txt",
    "30-Blueprint_UserWorkflow_FA.txt",
]

# بخش‌های الزامی در هر Blueprint
REQUIRED_SECTIONS = [
    (r'##.*تعریف|##.*Definition', 'تعریف/Definition'),
    (r'##.*هدف|##.*Purpose', 'هدف/Purpose'),
    (r'Dependencies:', 'Dependencies'),
    (r'Implementation Checklist', 'Implementation Checklist'),
]

# فایل‌های کلیدی که باید موجود باشند
REQUIRED_FILES = [
    "00-START-HERE/0-QUICK_START.md",
    "00-START-HERE/1-Master_Blueprint_Index_FA.txt",
    "00-START-HERE/CHANGELOG.md",
    "00-START-HERE/CONTRIBUTING.md",
    "07-Master-Blueprints/01-Blueprint_Master_FA_v2.0.txt",
]


# ================================================================================
# Validation Functions
# ================================================================================

class ProjectValidator:
    """کلاس اصلی برای Validation پروژه"""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.stats = ProjectStats()
        
    def add_result(self, category: str, severity: str, message: str, 
                   file_path: str = "", line_number: int = 0):
        """اضافه کردن یک نتیجه به لیست"""
        result = ValidationResult(category, severity, message, file_path, line_number)
        
        if severity == 'error':
            self.stats.errors.append(result)
        elif severity == 'warning':
            self.stats.warnings.append(result)
        else:
            self.stats.info.append(result)
    
    def validate_all(self) -> ProjectStats:
        """اجرای تمام Validation ها"""
        print("🔍 شروع بررسی پروژه...")
        print("=" * 70)
        
        # 1. چک کردن وجود پوشه
        if not self.project_path.exists():
            self.add_result('structure', 'error', 
                          f'پوشه پروژه پیدا نشد: {self.project_path}')
            return self.stats
        
        # 2. جمع‌آوری آمار کلی
        self._collect_stats()
        
        # 3. بررسی فایل‌های الزامی
        self._check_required_files()
        
        # 4. بررسی Blueprint ها
        self._check_blueprints()
        
        # 5. بررسی نام‌گذاری
        self._check_naming_conventions()
        
        # 6. بررسی ساختار Blueprint ها
        self._check_blueprint_structure()
        
        # 7. بررسی Dependencies
        self._check_dependencies()
        
        print("\n✅ بررسی کامل شد.")
        return self.stats
    
    def _collect_stats(self):
        """جمع‌آوری آمار کلی"""
        print("\n📊 جمع‌آوری آمار...")
        
        total_size = 0
        for file_path in self.project_path.rglob("*"):
            if file_path.is_file():
                self.stats.total_files += 1
                total_size += file_path.stat().st_size
                
                if "Blueprint" in file_path.name and file_path.suffix == ".txt":
                    if "Master" not in file_path.name and "Index" not in file_path.name:
                        self.stats.blueprint_count += 1
                
                if file_path.suffix in ['.txt', '.md']:
                    self.stats.doc_count += 1
        
        self.stats.total_size_mb = total_size / (1024 * 1024)
        
        self.add_result('stats', 'info', 
                       f'تعداد کل فایل‌ها: {self.stats.total_files}')
        self.add_result('stats', 'info', 
                       f'تعداد Blueprint ها: {self.stats.blueprint_count}')
        self.add_result('stats', 'info', 
                       f'حجم کل: {self.stats.total_size_mb:.2f} MB')
    
    def _check_required_files(self):
        """بررسی وجود فایل‌های الزامی"""
        print("📋 بررسی فایل‌های الزامی...")
        
        for required_file in REQUIRED_FILES:
            file_path = self.project_path / required_file
            if not file_path.exists():
                self.add_result('structure', 'error',
                              f'فایل الزامی موجود نیست: {required_file}')
            else:
                self.add_result('structure', 'info',
                              f'فایل الزامی موجود است: {required_file}')
    
    def _check_blueprints(self):
        """بررسی Blueprint ها"""
        print("🔍 بررسی Blueprint ها...")
        
        # پیدا کردن همه Blueprint ها
        found_blueprints = []
        for bp_file in self.project_path.rglob("*Blueprint*.txt"):
            if "Master" not in bp_file.name and "Index" not in bp_file.name:
                found_blueprints.append(bp_file.name)
        
        # چک کردن تعداد
        if len(found_blueprints) != len(EXPECTED_BLUEPRINTS):
            self.add_result('blueprints', 'warning',
                          f'تعداد Blueprint ها ({len(found_blueprints)}) '
                          f'با تعداد مورد انتظار ({len(EXPECTED_BLUEPRINTS)}) مطابقت ندارد')
        
        # چک کردن Blueprint های موجود
        found_set = set(found_blueprints)
        expected_set = set(EXPECTED_BLUEPRINTS)
        
        missing = expected_set - found_set
        extra = found_set - expected_set
        
        if missing:
            for bp in missing:
                self.add_result('blueprints', 'error',
                              f'Blueprint موجود نیست: {bp}')
        
        if extra:
            for bp in extra:
                self.add_result('blueprints', 'warning',
                              f'Blueprint اضافی پیدا شد: {bp}')
        
        if not missing and not extra:
            self.add_result('blueprints', 'info',
                          'همه Blueprint های مورد انتظار موجود هستند ✓')
    
    def _check_naming_conventions(self):
        """بررسی رعایت استانداردهای نام‌گذاری"""
        print("📝 بررسی نام‌گذاری...")
        
        # الگوی صحیح: NN-Blueprint_ModuleName_FA.txt
        pattern = re.compile(r'^\d{2}-Blueprint_[A-Z][A-Za-z]+_FA\.txt$')
        
        for bp_file in self.project_path.rglob("*Blueprint*.txt"):
            if "Master" in bp_file.name or "Index" in bp_file.name:
                continue
            
            if not pattern.match(bp_file.name):
                self.add_result('naming', 'warning',
                              f'نام‌گذاری مطابق استاندارد نیست: {bp_file.name}',
                              str(bp_file))
    
    def _check_blueprint_structure(self):
        """بررسی ساختار داخلی Blueprint ها"""
        print("🏗️  بررسی ساختار Blueprint ها...")
        
        for bp_file in self.project_path.rglob("*Blueprint*.txt"):
            if "Master" in bp_file.name or "Index" in bp_file.name:
                continue
            
            try:
                content = bp_file.read_text(encoding='utf-8')
                
                # چک کردن بخش‌های الزامی
                for pattern, section_name in REQUIRED_SECTIONS:
                    if not re.search(pattern, content, re.IGNORECASE):
                        self.add_result('structure', 'warning',
                                      f'بخش الزامی موجود نیست: {section_name}',
                                      str(bp_file))
                
                # چک کردن حجم (فایل‌های خیلی کوچک مشکوک هستند)
                size_kb = bp_file.stat().st_size / 1024
                if size_kb < 5:
                    self.add_result('structure', 'warning',
                                  f'حجم فایل بسیار کم است ({size_kb:.1f} KB) - احتمالاً ناقص',
                                  str(bp_file))
                
            except Exception as e:
                self.add_result('structure', 'error',
                              f'خطا در خواندن فایل: {e}',
                              str(bp_file))
    
    def _check_dependencies(self):
        """بررسی Dependencies"""
        print("🔗 بررسی Dependencies...")
        
        # نقشه وابستگی‌های مورد انتظار
        expected_deps = {
            "02-Blueprint_StoryWizard_FA.txt": [],
            "04-Blueprint_DNA_Manager_FA.txt": ["StoryWizard", "Story Wizard"],
            "09-Blueprint_ShotEngine_FA.txt": ["SceneEngine", "BeatSheetManager"],
            # می‌توان بقیه را اضافه کرد
        }
        
        for bp_file in self.project_path.rglob("*Blueprint*.txt"):
            if bp_file.name not in expected_deps:
                continue
            
            try:
                content = bp_file.read_text(encoding='utf-8')
                
                # جستجوی بخش Dependencies
                dep_match = re.search(r'Dependencies:\s*(.+?)(?:\n\n|\nNext Module)', 
                                     content, re.DOTALL)
                
                if not dep_match and expected_deps[bp_file.name]:
                    self.add_result('dependencies', 'warning',
                                  f'Dependencies تعریف نشده است',
                                  str(bp_file))
                
            except Exception as e:
                self.add_result('dependencies', 'error',
                              f'خطا در بررسی Dependencies: {e}',
                              str(bp_file))
    
    def print_report(self):
        """چاپ گزارش نهایی"""
        print("\n" + "=" * 70)
        print("📊 گزارش نهایی Validation")
        print("=" * 70)
        
        # آمار کلی
        print(f"\n📈 آمار کلی:")
        print(f"  • تعداد کل فایل‌ها: {self.stats.total_files}")
        print(f"  • تعداد Blueprint ها: {self.stats.blueprint_count}")
        print(f"  • تعداد مستندات: {self.stats.doc_count}")
        print(f"  • حجم کل: {self.stats.total_size_mb:.2f} MB")
        
        # خلاصه مشکلات
        print(f"\n🎯 خلاصه:")
        print(f"  • خطاها (Errors): {len(self.stats.errors)}")
        print(f"  • هشدارها (Warnings): {len(self.stats.warnings)}")
        print(f"  • اطلاعات (Info): {len(self.stats.info)}")
        
        # چاپ خطاها
        if self.stats.errors:
            print(f"\n❌ خطاها ({len(self.stats.errors)}):")
            for i, error in enumerate(self.stats.errors, 1):
                print(f"  {i}. [{error.category}] {error.message}")
                if error.file_path:
                    print(f"     📄 {error.file_path}")
        
        # چاپ هشدارها
        if self.stats.warnings:
            print(f"\n⚠️  هشدارها ({len(self.stats.warnings)}):")
            for i, warning in enumerate(self.stats.warnings[:10], 1):  # فقط 10 مورد اول
                print(f"  {i}. [{warning.category}] {warning.message}")
                if warning.file_path:
                    print(f"     📄 {warning.file_path}")
            
            if len(self.stats.warnings) > 10:
                print(f"  ... و {len(self.stats.warnings) - 10} هشدار دیگر")
        
        # نتیجه‌گیری
        print("\n" + "=" * 70)
        if not self.stats.errors:
            print("✅ هیچ خطای جدی پیدا نشد!")
            if not self.stats.warnings:
                print("🎉 پروژه کاملاً سالم و consistent است!")
            else:
                print(f"⚠️  {len(self.stats.warnings)} هشدار وجود دارد که بهتر است بررسی شوند.")
        else:
            print(f"❌ {len(self.stats.errors)} خطا پیدا شد که باید برطرف شوند.")
        
        print("=" * 70)
    
    def save_json_report(self, output_path: Path):
        """ذخیره گزارش به صورت JSON"""
        report = {
            "timestamp": datetime.now().isoformat(),
            "project_path": str(self.project_path),
            "stats": {
                "total_files": self.stats.total_files,
                "blueprint_count": self.stats.blueprint_count,
                "doc_count": self.stats.doc_count,
                "total_size_mb": self.stats.total_size_mb,
            },
            "summary": {
                "errors": len(self.stats.errors),
                "warnings": len(self.stats.warnings),
                "info": len(self.stats.info),
            },
            "errors": [
                {
                    "category": e.category,
                    "message": e.message,
                    "file": e.file_path,
                    "line": e.line_number
                }
                for e in self.stats.errors
            ],
            "warnings": [
                {
                    "category": w.category,
                    "message": w.message,
                    "file": w.file_path,
                    "line": w.line_number
                }
                for w in self.stats.warnings
            ],
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 گزارش JSON ذخیره شد: {output_path}")


# ================================================================================
# Main
# ================================================================================

def main():
    """تابع اصلی"""
    # دریافت مسیر پروژه
    if len(sys.argv) > 1:
        project_path = Path(sys.argv[1])
    else:
        project_path = Path.cwd()
    
    print("=" * 70)
    print("🔍 Project Validation Script")
    print("    Cinema Shot Generation Platform")
    print("=" * 70)
    print(f"\n📁 مسیر پروژه: {project_path}")
    
    # ساخت validator و اجرا
    validator = ProjectValidator(project_path)
    stats = validator.validate_all()
    
    # چاپ گزارش
    validator.print_report()
    
    # ذخیره JSON
    json_path = Path("validation_report.json")
    validator.save_json_report(json_path)
    
    # Exit code
    exit_code = 0 if not stats.errors else 1
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
